# responsive-collapsible-bootstrap-table

On small screens turns into a vertical list.

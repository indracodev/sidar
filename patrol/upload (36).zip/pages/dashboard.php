<template>
    <div class="page">
        <div class="navbar">
            <div class="navbar-bg"></div>
            <div class="navbar-inner">
                <div class="left left-navbar">
                    <a href="#" class="link back">
                        <span>Back</span>
                    </a>
                </div>
                <div class="title text-align-center" style="width: 100%;">Dashboard</div>
            </div>
        </div>

        <div class="page-content">
            <div style="max-width: 1280px; margin: 0 auto;">
                <div class="card card-outline">
                    <div class="card-header">
                        <span>Today Activity</span>
                        <a class="button button-raised" href="#" @click="${refresh}">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" class="bi bi-arrow-repeat" viewBox="0 0 16 16">
                                <path d="M11.534 7h3.932a.25.25 0 0 1 .192.41l-1.966 2.36a.25.25 0 0 1-.384 0l-1.966-2.36a.25.25 0 0 1 .192-.41zm-11 2h3.932a.25.25 0 0 0 .192-.41L2.692 6.23a.25.25 0 0 0-.384 0L.342 8.59A.25.25 0 0 0 .534 9z"/>
                                <path fill-rule="evenodd" d="M8 3c-1.552 0-2.94.707-3.857 1.818a.5.5 0 1 1-.771-.636A6.002 6.002 0 0 1 13.917 7H12.9A5.002 5.002 0 0 0 8 3zM3.1 9a5.002 5.002 0 0 0 8.757 2.182.5.5 0 1 1 .771.636A6.002 6.002 0 0 1 2.083 9H3.1z"/>
                            </svg>
                        </a>
                    </div>
                    <div class="card-content">
                        <div class="display-flex flex-direction-column">
                            ${phase && phase.map((phase, index) => $h`
                            <a data-reload-detail="true" @click="${()=> getActivity(phase)}" href="#" data-transition="f7-circle" class="button button-outline margin popup-open" data-popup="#activity-popup" style="width: 200px; height: 150px;">
                                <div class="display-flex flex-direction-column">
                                    <span style="font-size: xxx-large">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" class="bi bi-card-checklist" viewBox="0 0 16 16">
                                            <path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5h13zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z"/>
                                            <path d="M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0zM7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5zm-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0z"/>
                                        </svg>
                                    </span>
                                    <span style="text-transform: capitalize;">Phase ${index + 1}</span>
                                </div>
                            </a>
                            `)}
                            ${!phase && $h`
                            <div class="padding">
                                <span>No activity today!</span>
                            </div>
                            `}
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="popup" id="activity-popup">
            <div class="display-flex justify-content-center">
                <span class="padding" style="font-size: xx-large">Phase 1</span>
            </div>
            ${checkpoint && $h`
            <div class="timeline timeline-sides">
                ${checkpoint.map((activity) => $h`
                <div class="timeline-item timeline-item-right">
                    <div class="timeline-item-date">${activity.end || 'No data'}</div>
                    <div class="timeline-item-divider" style="background: ${activity.status}"></div>
                    <div class="timeline-item-content">
                        <div class="timeline-item-inner">
                            <span>Checkpoint : ${activity.checkpoint}</span><br/>
                            <span>Guard : ${activity.person}</span>
                        </div>
                    </div>
                </div>
                `)}
            </div>
            `}
            ${!checkpoint && $h`
            <div class="display-flex justify-content-center padding">
                <div class="preloader"></div>
            </div>
            `}
        </div>

    </div>
</template>
<script>
    "user strict"
    export default (props, {$on, $, $f7, $update, $tick}) => {
        let phase
        let checkpoint

        const formatDate = (date) => {
            var d = new Date(date),
                month = '' + (d.getMonth() + 1),
                day = '' + d.getDate(),
                year = d.getFullYear()

            if (month.length < 2)
                month = '0' + month
            if (day.length < 2)
                day = '0' + day

            return [year, month, day].join('-')
        }

        $on('page:mounted', () => {
            getPhase()
        })

        const getPhase = () => {
            try {
                model.getPhase({
                    date: formatDate(new Date())
                }, {
                    success: (data) => {
                        let res = JSON.parse(data)
                        phase = res.phaseId
                        $update()
                    }, error: () => {
                        toast('Connection problem!')
                    }
                })
            } catch (e) {
                toast('Code problem!')
            }
        }

        const getActivity = (e) => {
            try {
                model.getActivity({
                    hash: storage.getItem('hash-patrol') || '',
                    phase: e
                }, {
                    success: (data) => {
                        let res = JSON.parse(data)
                        checkpoint = res.schedule
                        $update()
                    }, error: () => {
                        toast('Connection problem!')
                    }
                })
            } catch (e) {
                toast('Code problem!')
            }
        }

        const refresh = () => {

        }

        return $render
    }
</script>
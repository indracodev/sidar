-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 21, 2021 at 03:24 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `guard`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_activity`
--

CREATE TABLE `tb_activity` (
  `uid` int(10) NOT NULL,
  `activityId` varchar(10) NOT NULL,
  `personId` varchar(2) DEFAULT NULL,
  `scheduleId` varchar(11) DEFAULT NULL,
  `checkpointStart` varchar(60) DEFAULT NULL,
  `checkpointEnd` varchar(60) DEFAULT NULL,
  `activityStart` datetime DEFAULT NULL,
  `activityEnd` datetime DEFAULT NULL,
  `activityStatus` varchar(1) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_activity`
--

INSERT INTO `tb_activity` (`uid`, `activityId`, `personId`, `scheduleId`, `checkpointStart`, `checkpointEnd`, `activityStart`, `activityEnd`, `activityStatus`, `lastUpdated`) VALUES
(41, '1', '1', '1', 'D', 'B', '2021-06-17 16:16:59', '2021-06-17 16:56:44', '1', '2021-06-17 09:56:44'),
(42, '2', '1', '2', 'B', 'A', '2021-06-17 17:21:25', '2021-06-17 17:22:42', '1', '2021-06-18 01:18:35'),
(47, '5', '1', '3', 'A', 'B', '2021-06-21 08:19:54', '2021-06-21 08:20:08', '1', '2021-06-21 01:20:08'),
(49, '7', '1', '4', NULL, NULL, NULL, NULL, '0', '2021-06-18 10:54:02'),
(50, '8', '1', '5', NULL, NULL, NULL, NULL, '0', '2021-06-18 07:25:52');

-- --------------------------------------------------------

--
-- Table structure for table `tb_checkpoint`
--

CREATE TABLE `tb_checkpoint` (
  `uid` int(2) NOT NULL,
  `checkpointId` varchar(20) NOT NULL,
  `checkpointName` varchar(60) NOT NULL,
  `checkLatitude` varchar(255) DEFAULT NULL,
  `checkLongitude` varchar(255) DEFAULT NULL,
  `checkStatus` varchar(1) NOT NULL,
  `userName` varchar(60) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_checkpoint`
--

INSERT INTO `tb_checkpoint` (`uid`, `checkpointId`, `checkpointName`, `checkLatitude`, `checkLongitude`, `checkStatus`, `userName`, `lastUpdated`) VALUES
(6, '04dd6bda386680', 'A', NULL, NULL, '1', 'root', '2021-06-18 05:54:38'),
(7, '044eeab2ac6d80', '7', NULL, NULL, '1', 'root', '2021-06-14 18:49:37'),
(9, '0447ebb2ac6d80', '3', NULL, NULL, '1', 'root', '2021-06-14 18:49:43'),
(12, '044aeab2ac6d80', '2', NULL, NULL, '1', 'root', '2021-06-18 05:37:56'),
(13, '0456eab2ac6d80', '6', NULL, NULL, '0', 'admin', '2021-06-14 18:56:29'),
(14, '0452eab2ac6d80', '5', NULL, NULL, '0', 'admin', '2021-06-14 18:57:06'),
(15, '044b6dea5c6480', 'B', NULL, NULL, '1', 'root', '2021-06-16 06:36:44'),
(16, '04ed6aea5c6480', 'C', NULL, NULL, '1', 'root', '2021-06-16 06:36:46'),
(17, '045d32da386681', 'D', NULL, NULL, '0', 'root', '2021-06-18 09:31:00');

-- --------------------------------------------------------

--
-- Table structure for table `tb_person`
--

CREATE TABLE `tb_person` (
  `uid` int(5) NOT NULL,
  `personId` varchar(2) NOT NULL,
  `personName` varchar(60) NOT NULL,
  `userName` varchar(60) NOT NULL,
  `personStatus` varchar(1) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_person`
--

INSERT INTO `tb_person` (`uid`, `personId`, `personName`, `userName`, `personStatus`, `lastUpdated`) VALUES
(1, '1', 'yoggy', 'admin', '1', '2021-06-17 07:09:13'),
(2, '2', 'messi', 'admin', '1', '2021-06-17 07:09:17'),
(4, '3', 'amir', 'admin', '1', '2021-06-15 08:57:02'),
(6, '4', 'nanda', 'admin', '1', '2021-06-15 09:00:55'),
(8, '5', 'Aldy', 'root', '0', '2021-06-18 06:00:54');

-- --------------------------------------------------------

--
-- Table structure for table `tb_phase`
--

CREATE TABLE `tb_phase` (
  `uid` int(11) NOT NULL,
  `phaseId` varchar(11) NOT NULL,
  `phaseDate` date NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_phase`
--

INSERT INTO `tb_phase` (`uid`, `phaseId`, `phaseDate`, `lastUpdated`) VALUES
(9, '1', '2021-06-17', '2021-06-17 08:23:00'),
(14, '2', '2021-06-18', '2021-06-18 07:24:20');

-- --------------------------------------------------------

--
-- Table structure for table `tb_report`
--

CREATE TABLE `tb_report` (
  `uid` int(10) NOT NULL,
  `reportId` varchar(10) NOT NULL,
  `reportLatitude` varchar(255) NOT NULL,
  `reportLongitude` varchar(255) NOT NULL,
  `activityId` varchar(10) NOT NULL,
  `personId` varchar(2) NOT NULL,
  `checkpointName` varchar(60) NOT NULL,
  `reportDate` date NOT NULL,
  `reportTime` time NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_report`
--

INSERT INTO `tb_report` (`uid`, `reportId`, `reportLatitude`, `reportLongitude`, `activityId`, `personId`, `checkpointName`, `reportDate`, `reportTime`, `lastUpdated`) VALUES
(38, '1', '29', '33', '1', '1', 'D', '2021-06-17', '17:27:30', '2021-06-17 10:27:30'),
(39, '2', '29', '33', '1', '1', 'B', '2021-06-18', '08:07:38', '2021-06-18 01:07:38'),
(55, '3', '-7.2934296', '112.6752927', '5', '1', 'A', '2021-06-21', '08:19:54', '2021-06-21 01:19:54'),
(56, '4', '-7.2934297', '112.6752885', '5', '1', 'B', '2021-06-21', '08:20:08', '2021-06-21 01:20:08');

-- --------------------------------------------------------

--
-- Table structure for table `tb_schedule`
--

CREATE TABLE `tb_schedule` (
  `uid` int(11) NOT NULL,
  `scheduleId` varchar(11) NOT NULL,
  `personId` varchar(2) NOT NULL,
  `activityId` varchar(10) DEFAULT NULL,
  `checkpointName` varchar(60) NOT NULL,
  `phaseId` varchar(11) NOT NULL,
  `scheduleStart` time NOT NULL,
  `scheduleEnd` time NOT NULL,
  `scheduleDate` date NOT NULL,
  `userName` varchar(60) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_schedule`
--

INSERT INTO `tb_schedule` (`uid`, `scheduleId`, `personId`, `activityId`, `checkpointName`, `phaseId`, `scheduleStart`, `scheduleEnd`, `scheduleDate`, `userName`, `lastUpdated`) VALUES
(23, '1', '1', '1', 'D', '1', '16:30:00', '17:00:00', '2021-06-17', 'root', '2021-06-18 01:10:27'),
(24, '2', '1', '2', 'B', '1', '17:00:00', '17:30:00', '2021-06-17', 'root', '2021-06-17 09:13:33'),
(27, '3', '1', '5', 'A', '2', '14:00:00', '14:20:00', '2021-06-18', 'root', '2021-06-18 07:24:47'),
(29, '4', '1', '7', 'B', '2', '14:25:00', '14:45:00', '2021-06-18', 'root', '2021-06-18 07:25:28'),
(30, '5', '1', '8', 'C', '2', '14:50:00', '15:10:00', '2021-06-18', 'root', '2021-06-18 07:25:52');

-- --------------------------------------------------------

--
-- Table structure for table `tb_users`
--

CREATE TABLE `tb_users` (
  `uid` int(5) NOT NULL,
  `userId` varchar(5) NOT NULL,
  `userName` varchar(60) NOT NULL,
  `userPassword` varchar(255) NOT NULL,
  `userLevel` varchar(2) NOT NULL,
  `hashMobile` varchar(255) NOT NULL,
  `hashWeb` varchar(255) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_users`
--

INSERT INTO `tb_users` (`uid`, `userId`, `userName`, `userPassword`, `userLevel`, `hashMobile`, `hashWeb`, `lastUpdated`) VALUES
(1, '1', 'admin', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', '1', 'bPcYiTvs1Ny2vWtPRynp7BySuDlBYXtgNvT2D7jbV1HWDu76pn', 'F1TAj8z2pLW4btgBGt9wtZS7gu7RvO5a0st7fkHzhZD3r9VkpC', '2021-06-18 04:10:15'),
(2, '0', 'root', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '10', 'egMbF6UcQcO6ifnUPlGMjSWUOmzDTOm3naqiI4UfqUi2UzBwit', 'ckO7fxhKveHXDcQVpbACivRJQzHzJtvb0ki8Dc6zhEps5FIwJv', '2021-06-21 01:22:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_activity`
--
ALTER TABLE `tb_activity`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `activityId` (`activityId`);

--
-- Indexes for table `tb_checkpoint`
--
ALTER TABLE `tb_checkpoint`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `checkpointId` (`checkpointId`);

--
-- Indexes for table `tb_person`
--
ALTER TABLE `tb_person`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `personId` (`personId`);

--
-- Indexes for table `tb_phase`
--
ALTER TABLE `tb_phase`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `phaseId` (`phaseId`);

--
-- Indexes for table `tb_report`
--
ALTER TABLE `tb_report`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `tb_schedule`
--
ALTER TABLE `tb_schedule`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `scheduleId` (`scheduleId`);

--
-- Indexes for table `tb_users`
--
ALTER TABLE `tb_users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `userId` (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_activity`
--
ALTER TABLE `tb_activity`
  MODIFY `uid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `tb_checkpoint`
--
ALTER TABLE `tb_checkpoint`
  MODIFY `uid` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tb_person`
--
ALTER TABLE `tb_person`
  MODIFY `uid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tb_phase`
--
ALTER TABLE `tb_phase`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `tb_report`
--
ALTER TABLE `tb_report`
  MODIFY `uid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `tb_schedule`
--
ALTER TABLE `tb_schedule`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `tb_users`
--
ALTER TABLE `tb_users`
  MODIFY `uid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

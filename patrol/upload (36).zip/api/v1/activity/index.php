<?php
include '../../config.php';
$output;

//Checked
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $personId = $_POST['person'];
    $checkpointId = $_POST['checkpoint'];
    $activityAction = $_POST['action'];
    $reportTime = date('H:i:s');
    $reportDate = date('Y-m-d');

    if (isset($personId) && !empty($personId) && $personId != 'undefined' &&
        isset($checkpointId) && !empty($checkpointId) && $checkpointId != 'undefined' &&
        isset($activityAction) && !empty($activityAction) && $activityAction != 'undefined') {

        switch ($activityAction) {
            case 'start':
                $sql = $conn->prepare("SELECT activityId, scheduleId FROM tb_activity WHERE personId = ? AND activityStatus = '0' ORDER BY activityId ASC LIMIT 1");
                $sql->bind_param('s', $personId); $sql->execute();
                $activityResult = $sql->get_result();
                if ($activityResult->num_rows > 0) {
                    $activityId;
                    $scheduleId;
                    while ($rowActivity = $activityResult->fetch_assoc()) {
                        $activityId = $rowActivity['activityId'];
                        $scheduleId = $rowActivity['scheduleId'];
                    }
                    $sql = $conn->prepare("SELECT checkpointName FROM tb_checkpoint WHERE checkpointId = ?");
                    $sql->bind_param('s', $checkpointId); $sql->execute();
                    $checkpointResult = $sql->get_result();
                    if ($checkpointResult->num_rows > 0) {
                        $checkpointName;
                        while ($row = $checkpointResult->fetch_assoc()) {
                            $checkpointName = $row['checkpointName'];
                        }
                        $sql = $conn->prepare("UPDATE tb_activity SET checkpointStart = ?, activityStart = ? WHERE activityId = ?"); $sql->bind_param("sss", $checkpointName, date('Y-m-d H:i:s'), $activityId);
                        if ($sql->execute() === TRUE) {
                            $sql = $conn->prepare("SELECT scheduleStart, scheduleEnd FROM tb_schedule WHERE scheduleId = ?");
                            $sql->bind_param('s', $scheduleId); $sql->execute();
                            $scheduleResult = $sql->get_result();
                            if ($scheduleResult->num_rows > 0) {
                                $schedule;
                                while ($rowSchedule = $scheduleResult->fetch_assoc()) {
                                    $schedule = (object) [
                                        checkpoint => $checkpointName,
                                        start => $rowSchedule['scheduleStart'],
                                        end => $rowSchedule['scheduleEnd']
                                    ];
                                }
                                $output->status = 'success';
                                $output->activity = $activityId;
                                $output->schedule = $scheduleId;
                                $output->progress = $schedule;
                                $output->action = $activityAction;
                                echo(json_encode($output));
                            } else {
                                $output->status = 'false';
                                $output->action = $activityAction;
                                echo(json_encode($output));
                            }
                        } else {
                            $output->status = 'failed';
                            $output->action = 'update';
                            echo(json_encode($output));
                        }
                    } else {
                        $output->status = 'false';
                        $output->action = $activityAction;
                        echo(json_encode($output));
                    }
                } else {
                    $output->status = 'unknown';
                    $output->action = $activityAction;
                    echo(json_encode($output));
                }
                break;
            case 'end':
                $sql = $conn->prepare("SELECT activityId, scheduleId FROM tb_activity WHERE personId = ? AND activityStart IS NOT NULL AND checkpointStart IS NOT NULL");
                $sql->bind_param('s', $personId); $sql->execute();
                $activityResult = $sql->get_result();
                if ($activityResult->num_rows > 0) {
                    $activityId;
                    $scheduleId;
                    while ($rowActivity = $activityResult->fetch_assoc()) {
                        $activityId = $rowActivity['activityId'];
                        $scheduleId = $rowActivity['scheduleId'];
                    }
                    $sql = $conn->prepare("SELECT checkpointName FROM tb_checkpoint WHERE checkpointId = ?");
                    $sql->bind_param('s', $checkpointId); $sql->execute();
                    $checkpointResult = $sql->get_result();
                    if ($checkpointResult->num_rows > 0) {
                        $checkpointName;
                        while ($row = $checkpointResult->fetch_assoc()) {
                            $checkpointName = $row['checkpointName'];
                        }
                        $sql = $conn->prepare("UPDATE tb_activity SET checkpointEnd = ?, activityEnd = ?, activityStatus = '1' WHERE activityId = ?"); $sql->bind_param("sss", $checkpointName, date('Y-m-d H:i:s'), $activityId);
                        if ($sql->execute() === TRUE) {
                            $output->status = 'success';
                            $output->activity = $activityId;
                            $output->schedule = $scheduleId;
                            echo(json_encode($output));
                        } else {
                            $output->status = 'failed';
                            $output->action = 'update';
                            echo(json_encode($output));
                        }
                    } else {
                        $output->status = 'false';
                        echo(json_encode($output));
                    }
                } else {
                    $output->status = 'unknown';
                    echo(json_encode($output));
                }
                break;
        }
//        $timeCheck = substr($reportDate, 0, 10).' '.substr($reportTime, 0, 4).'%';
//        $activityCheck = $conn->prepare("SELECT activityId FROM tb_activity WHERE personId = ? AND activityStatus = '0' AND activityStart NOT LIKE ?");
//        $activityCheck->bind_param('ss', $personId, $timeCheck);
//        $activityCheck->execute();
//        $activityResult = $activityCheck->get_result();
//        if ($activityResult->num_rows > 0) {
//            while ($rowActivity = $activityResult->fetch_assoc()) {
//
//                $activityId = $rowActivity['activityId'];
//                $sql = $conn->prepare("UPDATE tb_activity SET activityEnd = ?, activityStatus = '1' WHERE personId = ? AND activityId = ?");
//                $sql->bind_param('sss', date('Y-m-d H:i:s'),$personId, $activityId);
//                if ($sql->execute() === TRUE) {
//                    $reportCheck = $conn->prepare("SELECT reportId FROM tb_report ORDER BY reportId DESC LIMIT 1");
//                    $reportCheck->execute();
//                    $resultReport = $reportCheck->get_result();
//                    if ($resultReport->num_rows > 0) {
//                        while ($rowCheck = $resultReport->fetch_assoc()) {
//
//                            $reportId = (int)$rowCheck['reportId'] + 1;
//                            $checkpointCheck = $conn->prepare("SELECT checkpointName FROM tb_checkpoint WHERE checkpointId = ?");
//                            $checkpointCheck->bind_param('s', $checkpointId);
//                            $checkpointCheck->execute();
//                            $resultCheckpoint = $checkpointCheck->get_result();
//                            if ($resultCheckpoint->num_rows > 0) {
//                                while ($row = $resultCheckpoint->fetch_assoc()) {
//
//                                    $sql = $conn->prepare("INSERT INTO tb_report (reportId, reportLatitude, reportLongitude, activityId, personId, checkpointName, reportDate, reportTime) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
//                                    $sql->bind_param('ssssssss', $reportId, $reportLatitude, $reportLongitude, $activityId, $personId, $row['checkpointName'], $reportDate, $reportTime);
//                                    if ($sql->execute() === TRUE) {
//
//                                        $output->status = 'success';
//                                        $output->checkpoint = $row['checkpointName'];
//                                        echo(json_encode($output));
//
//                                    } else {
//                                        $output->status = 'failed';
//                                        echo(json_encode($output));
//                                    }
//
//                                }
//                            } else {
//                                $output->status = 'false';
//                                echo(json_encode($output));
//                            }
//
//                        }
//                    }
//                } else {
//                    $output->status = 'failed';
//                    echo(json_encode($output));
//                }
//
//            }
//        } else {
//            $sqlCheck = $conn->prepare("SELECT activityId FROM tb_activity ORDER BY activityId DESC LIMIT 1");
//            $sqlCheck->execute();
//            $resultCheck = $sqlCheck->get_result();
//            if ($resultCheck->num_rows > 0) {
//                while ($rowCheck = $resultCheck->fetch_assoc()) {
//
//                    $time = substr($reportTime, 0, 4).'%';
//                    $sqlSchedule = $conn->prepare("SELECT scheduleStart, scheduleEnd FROM tb_schedule WHERE scheduleDate = ? AND scheduleStart LIKE ?");
//                    $sqlSchedule->bind_param('ss', $reportDate, $time);
//                    $sqlSchedule->execute();
//                    $resultSchedule = $sqlSchedule->get_result();
//                    if ($resultSchedule->num_rows > 0) {
//                        while ($rowSchedule = $resultSchedule->fetch_assoc()) {
//
//                            $activityId = (int)$rowCheck['activityId'] + 1;
//                            $activityStatus = '0';
//                            $sql = $conn->prepare("INSERT INTO tb_activity (activityId, personId, activityStart, activityStatus) VALUES (?, ?, ?, ?)");
//                            $sql->bind_param("isss", $activityId, $personId, date('Y-m-d H:i:s'), $activityStatus);
//                            if ($sql->execute() === TRUE) {
//                                $reportCheck = $conn->prepare("SELECT reportId FROM tb_report ORDER BY reportId DESC LIMIT 1");
//                                $reportCheck->execute();
//                                $resultReport = $reportCheck->get_result();
//                                if ($resultReport->num_rows > 0) {
//                                    while ($rowCheck = $resultReport->fetch_assoc()) {
//                                        $reportId = (int)$rowCheck['reportId'] + 1;
//                                        $checkpointCheck = $conn->prepare("SELECT checkpointName FROM tb_checkpoint WHERE checkpointId = ?");
//                                        $checkpointCheck->bind_param('s', $checkpointId);
//                                        $checkpointCheck->execute();
//                                        $resultCheckpoint = $checkpointCheck->get_result();
//                                        if ($resultCheckpoint->num_rows > 0) {
//                                            while ($row = $resultCheckpoint->fetch_assoc()) {
//                                                $sql = $conn->prepare("INSERT INTO tb_report (reportId, reportLatitude, reportLongitude, activityId, personId, checkpointName, reportDate, reportTime) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
//                                                $sql->bind_param('ssssssss', $reportId, $reportLatitude, $reportLongitude, $activityId, $personId, $row['checkpointName'], $reportDate, $reportTime);
//                                                if ($sql->execute() === TRUE) {
//                                                    $output->status = 'success';
//                                                    $output->checkpoint = $row['checkpointName'];
//                                                    $output->scheduleStart = $rowSchedule['scheduleStart'];
//                                                    $output->scheduleEnd = $rowSchedule['scheduleEnd'];
//                                                    echo(json_encode($output));
//                                                } else {
//                                                    $output->status = 'failed';
//                                                    echo(json_encode($output));
//                                                }
//                                            }
//                                        } else {
//                                            $output->status = 'false';
//                                            echo(json_encode($output));
//                                        }
//                                    }
//                                } else {
//                                    $reportId = '1';
//                                    $checkpointCheck = $conn->prepare("SELECT checkpointName FROM tb_checkpoint WHERE checkpointId = ?");
//                                    $checkpointCheck->bind_param('s', $checkpointId);
//                                    $checkpointCheck->execute();
//                                    $resultCheckpoint = $checkpointCheck->get_result();
//                                    if ($resultCheckpoint->num_rows > 0) {
//                                        while ($row = $resultCheckpoint->fetch_assoc()) {
//
//                                            $sql = $conn->prepare("INSERT INTO tb_report (reportId, reportLatitude, reportLongitude, activityId, personId, checkpointName, reportDate, reportTime) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
//                                            $sql->bind_param('ssssssss', $reportId, $reportLatitude, $reportLongitude, $activityId, $personId, $row['checkpointName'], $reportDate, $reportTime);
//                                            if ($sql->execute() === TRUE) {
//                                                $output->status = 'success';
//                                                $output->checkpoint = $row['checkpointName'];
//                                                $output->scheduleStart = $rowSchedule['scheduleStart'];
//                                                $output->scheduleEnd = $rowSchedule['scheduleEnd'];
//                                                echo(json_encode($output));
//                                            } else {
//                                                $output->status = 'failed';
//                                                echo(json_encode($output));
//                                            }
//
//                                        }
//                                    } else {
//                                        $output->status = 'false';
//                                        echo(json_encode($output));
//                                    }
//                                }
//                            } else {
//                                $output->status = 'failed';
//                                echo(json_encode($output));
//                            }
//
//                        }
//                    } else {
//                        $output->status = 'false';
//                        echo(json_encode($output));
//                    }
//                }
//            } else {
//                $time = substr($reportTime, 0, 4).'%';
//                $sqlSchedule = $conn->prepare("SELECT scheduleStart, scheduleEnd FROM tb_schedule WHERE scheduleDate = ? AND scheduleStart LIKE ?");
//                $sqlSchedule->bind_param('ss', $reportDate, $time);
//                $sqlSchedule->execute();
//                $resultSchedule = $sqlSchedule->get_result();
//                if ($resultSchedule->num_rows > 0) {
//                    while ($rowSchedule = $resultSchedule->fetch_assoc()) {
//
//                        $activityId = '1';
//                        $activityStatus = '0';
//                        $sql = $conn->prepare("INSERT INTO tb_activity (activityId, personId, activityStart, activityStatus) VALUES (?, ?, ?, ?)");
//                        $sql->bind_param("isss", $activityId, $personId, date('Y-m-d H:i:s'), $activityStatus);
//                        if ($sql->execute() === TRUE) {
//                            $reportCheck = $conn->prepare("SELECT reportId FROM tb_report ORDER BY reportId DESC LIMIT 1");
//                            $reportCheck->execute();
//                            $resultReport = $reportCheck->get_result();
//                            if ($resultReport->num_rows > 0) {
//                                while ($rowCheck = $resultReport->fetch_assoc()) {
//
//                                    $reportId = (int)$rowCheck['reportId'] + 1;
//                                    $checkpointCheck = $conn->prepare("SELECT checkpointName FROM tb_checkpoint WHERE checkpointId = ?");
//                                    $checkpointCheck->bind_param('s', $checkpointId);
//                                    $checkpointCheck->execute();
//                                    $resultCheckpoint = $checkpointCheck->get_result();
//                                    if ($resultCheckpoint->num_rows > 0) {
//                                        while ($row = $resultCheckpoint->fetch_assoc()) {
//                                            $sql = $conn->prepare("INSERT INTO tb_report (reportId, reportLatitude, reportLongitude, activityId, personId, checkpointName, reportDate, reportTime) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
//                                            $sql->bind_param('ssssssss', $reportId, $reportLatitude, $reportLongitude, $activityId, $personId, $row['checkpointName'], $reportDate, $reportTime);
//                                            if ($sql->execute() === TRUE) {
//                                                $output->status = 'success';
//                                                $output->checkpoint = $row['checkpointName'];
//                                                $output->scheduleStart = $rowSchedule['scheduleStart'];
//                                                $output->scheduleEnd = $rowSchedule['scheduleEnd'];
//                                                echo(json_encode($output));
//                                            } else {
//                                                $output->status = 'failed';
//                                                echo(json_encode($output));
//                                            }
//                                        }
//                                    } else {
//                                        $output->status = 'false';
//                                        echo(json_encode($output));
//                                    }
//
//                                }
//                            } else {
//                                $reportId = '1';
//                                $checkpointCheck = $conn->prepare("SELECT checkpointName FROM tb_checkpoint WHERE checkpointId = ?");
//                                $checkpointCheck->bind_param('s', $checkpointId);
//                                $checkpointCheck->execute();
//                                $resultCheckpoint = $checkpointCheck->get_result();
//                                if ($resultCheckpoint->num_rows > 0) {
//                                    while ($row = $resultCheckpoint->fetch_assoc()) {
//
//                                        $sql = $conn->prepare("INSERT INTO tb_report (reportId, reportLatitude, reportLongitude, activityId, personId, checkpointName, reportDate, reportTime) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
//                                        $sql->bind_param('ssssssss', $reportId, $reportLatitude, $reportLongitude, $activityId, $personId, $row['checkpointName'], $reportDate, $reportTime);
//                                        if ($sql->execute() === TRUE) {
//                                            $output->status = 'success';
//                                            $output->checkpoint = $row['checkpointName'];
//                                            $output->scheduleStart = $rowSchedule['scheduleStart'];
//                                            $output->scheduleEnd = $rowSchedule['scheduleEnd'];
//                                            echo(json_encode($output));
//                                        } else {
//                                            $output->status = 'failed';
//                                            echo(json_encode($output));
//                                        }
//
//                                    }
//                                } else {
//                                    $output->status = 'false';
//                                    echo(json_encode($output));
//                                }
//                            }
//                        } else {
//                            $output->status = 'failed';
//                            echo(json_encode($output));
//                        }
//
//                    }
//                } else {
//                    $output->status = 'false';
//                    echo(json_encode($output));
//                }
//            }
//
//        }
    } elseif (isset($activityAction) && !empty($activityAction) && $activityAction != 'undefined' && $activityAction === 'schedule' &&
        isset($personId) && !empty($personId) && $personId != 'undefined') {
        $sql = $conn->prepare("SELECT activityId FROM tb_activity ORDER BY activityId DESC LIMIT 1"); $sql->execute();
        $resultCheck = $sql->get_result();
        if ($resultCheck->num_rows > 0) {
            while ($rowCheck = $resultCheck->fetch_assoc()) {
                $activityId = (int)$rowCheck['activityId'] + 1;
                $sql = $conn->prepare("INSERT INTO tb_activity (activityId, personId, activityStatus) VALUES (?, ?, '0')"); $sql->bind_param("is", $activityId, $personId);
                if ($sql->execute() === TRUE) {
                    $output->status = 'success';
                    $output->activity = $activityId;
                    echo(json_encode($output));
                } else {
                    $output->status = 'failed';
                    $output->action = 'insert';
                    echo(json_encode($output));
                }
            }
        } else {
            $activityId = '1';
            $sql = $conn->prepare("INSERT INTO tb_activity (activityId, personId, activityStatus) VALUES (?, ?, '0')"); $sql->bind_param("is", $activityId, $personId);
            if ($sql->execute() === TRUE) {
                $output->status = 'success';
                echo(json_encode($output));
            } else {
                $output->status = 'failed';
                $output->action = 'insert';
                echo(json_encode($output));
            }
        }
    } else {
        $output->status = 'error';
        echo(json_encode($output));
    }
}

//Checked
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $phaseId = $_GET['phase'];
    $scheduleId = $_GET['schedule'];
    $userHash = $_GET['hash'];

    if (isset($scheduleId) && !empty($scheduleId) && $scheduleId != 'undefined') {
        $sql = $conn->prepare("SELECT phaseId FROM tb_schedule WHERE scheduleId = ?");
        $sql->bind_param('s', $scheduleId); $sql->execute();
        $phaseResult = $sql->get_result();
        if ($phaseResult->num_rows > 0) {
            $phaseId;
            while ($rowPhase = $phaseResult->fetch_assoc()) {
                $phaseId = $rowPhase['phaseId'];
            }
            $sql = $conn->prepare("SELECT checkpointName, activityStatus FROM tb_schedule, tb_activity WHERE tb_activity.activityId = tb_schedule.activityID AND tb_schedule.phaseId = ?");
            $sql->bind_param('s', $phaseId); $sql->execute();
            $result = $sql->get_result();
            if ($result->num_rows > 0) {
                $scheduleArray = [];
                while ($row = $result->fetch_assoc()) {

                    switch ($row['activityStatus']) {
                        case '0':
                            $scheduleArray[] = (object) [
                                checkpoint => $row['checkpointName'],
                                status => 'red'
                            ];
                            break;
                        case '1':
                            $scheduleArray[] = (object) [
                                checkpoint => $row['checkpointName'],
                                status => 'green'
                            ];
                            break;
                    }

                }
                $output->status = 'success';
                $output->schedule = $scheduleArray;
                echo(json_encode($output));
            } else {
                $output->status = 'false';
                echo(json_encode($output));
            }
        } else {
            $output->status = 'false';
            echo(json_encode($output));
        }
    } elseif (isset($userHash) && !empty($userHash) && $userHash != 'undefined' &&
        isset($phaseId) && !empty($phaseId) && $phaseId != 'undefined') {
        $sql = $conn->prepare("SELECT checkpointName, activityStatus, activityStart, activityEnd, personName
            FROM tb_schedule, tb_activity, tb_person
            WHERE tb_activity.activityId = tb_schedule.activityID AND tb_person.personId = tb_schedule.personId AND tb_schedule.phaseId = ?");
        $sql->bind_param('s', $phaseId); $sql->execute();
        $result = $sql->get_result();
        if ($result->num_rows > 0) {
            $scheduleArray = [];
            while ($row = $result->fetch_assoc()) {

                switch ($row['activityStatus']) {
                    case '0':
                        if ($row['activityStart']) {
                            $scheduleArray[] = (object) [
                                checkpoint => $row['checkpointName'],
                                end => null,
                                person => ucfirst($row['personName']),
                                status => 'blue'
                            ];
                        } else {
                            $scheduleArray[] = (object) [
                                checkpoint => $row['checkpointName'],
                                end => null,
                                person => ucfirst($row['personName']),
                                status => 'red'
                            ];
                        }
                        break;
                    case '1':
                        $scheduleArray[] = (object) [
                            checkpoint => $row['checkpointName'],
                            end => date('j M H:i:s', strtotime($row['activityEnd'])),
                            person => ucfirst($row['personName']),
                            status => 'green'
                        ];
                        break;
                }

            }
            $output->status = 'success';
            $output->schedule = $scheduleArray;
            echo(json_encode($output));
        } else {
            $output->status = 'false';
            echo(json_encode($output));
        }
    } else {
        $output->status = 'error';
        echo(json_encode($output));
    }
}
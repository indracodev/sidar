-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 13, 2021 at 06:37 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `guard`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_activity`
--

CREATE TABLE `tb_activity` (
  `uid` int(10) NOT NULL,
  `activityId` varchar(10) NOT NULL,
  `personId` varchar(2) DEFAULT NULL,
  `scheduleId` varchar(11) DEFAULT NULL,
  `checkpointStart` varchar(60) DEFAULT NULL,
  `checkpointEnd` varchar(60) DEFAULT NULL,
  `activityStart` datetime DEFAULT NULL,
  `activityEnd` datetime DEFAULT NULL,
  `activityStatus` varchar(1) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_activity`
--

INSERT INTO `tb_activity` (`uid`, `activityId`, `personId`, `scheduleId`, `checkpointStart`, `checkpointEnd`, `activityStart`, `activityEnd`, `activityStatus`, `lastUpdated`) VALUES
(41, '1', '1', '1', 'D', 'B', '2021-06-17 16:16:59', '2021-06-17 16:56:44', '1', '2021-06-16 19:56:44'),
(42, '2', '1', '2', 'B', 'A', '2021-06-17 17:21:25', '2021-06-17 17:22:42', '1', '2021-06-17 11:18:35'),
(51, '3', '1', '3', 'Z', 'B', '2021-06-22 16:51:15', '2021-06-22 16:51:51', '1', '2021-06-22 02:51:51'),
(53, '4', '1', '4', 'B', 'Z', '2021-06-22 16:52:11', '2021-06-22 16:52:25', '1', '2021-06-22 02:52:25'),
(54, '5', '1', '5', NULL, NULL, NULL, NULL, '-', '2021-06-22 02:52:25'),
(55, '6', '1', '6', NULL, NULL, NULL, NULL, '-', '2021-06-22 02:52:25'),
(58, '7', '2', '7', 'Z', 'D', '2021-06-22 16:53:04', '2021-06-22 16:53:26', '1', '2021-06-22 02:53:26'),
(59, '8', '2', '8', 'D', 'B', '2021-06-22 16:53:46', '2021-06-22 16:54:04', '1', '2021-06-22 02:54:04'),
(60, '9', '2', '9', 'B', 'Z', '2021-06-22 16:54:25', '2021-06-22 16:54:42', '1', '2021-06-22 02:54:42'),
(61, '10', '2', '10', NULL, NULL, NULL, NULL, '-', '2021-06-22 02:54:42'),
(67, '11', '1', '11', 'Z', '7', '2021-06-28 09:31:38', '2021-06-28 09:33:26', '1', '2021-06-27 19:33:26'),
(69, '12', '1', '12', '7', '6', '2021-06-28 09:36:17', '2021-06-28 09:38:05', '1', '2021-06-27 19:38:05'),
(70, '13', '1', '13', '6', NULL, '2021-06-28 09:42:51', NULL, '-', '2021-06-27 20:04:34'),
(71, '14', '1', '14', '5', '3', '2021-06-28 09:48:15', '2021-06-28 09:50:42', '1', '2021-06-27 19:50:42'),
(72, '15', '1', '15', '3', '2', '2021-06-28 09:54:20', '2021-06-28 09:56:45', '1', '2021-06-27 19:56:45'),
(74, '16', '1', '16', '2', 'Z', '2021-06-28 10:00:40', '2021-06-28 10:04:34', '1', '2021-06-27 20:04:34'),
(75, '17', '1', '17', NULL, NULL, NULL, NULL, '0', '2021-06-28 08:14:58'),
(76, '18', '1', '18', NULL, NULL, NULL, NULL, '0', '2021-06-28 08:14:47'),
(77, '19', '2', '19', NULL, NULL, NULL, NULL, '0', '2021-06-28 08:14:35'),
(78, '20', '1', '20', NULL, NULL, NULL, NULL, '0', '2021-06-28 08:14:33'),
(81, '21', '1', '21', 'Z', 'C', '2021-07-08 17:15:19', '2021-07-08 17:15:52', '1', '2021-07-08 10:15:52'),
(82, '22', '1', '22', 'C', 'D', '2021-07-08 17:16:11', '2021-07-08 17:16:29', '1', '2021-07-08 10:16:29'),
(83, '23', '1', '23', 'D', 'B', '2021-07-08 17:16:39', '2021-07-08 17:16:56', '1', '2021-07-08 10:16:56'),
(84, '24', '1', '24', 'B', 'Z', '2021-07-08 17:17:07', '2021-07-08 17:17:34', '1', '2021-07-08 10:17:34');

-- --------------------------------------------------------

--
-- Table structure for table `tb_checkpoint`
--

CREATE TABLE `tb_checkpoint` (
  `uid` int(2) NOT NULL,
  `checkpointId` varchar(20) NOT NULL,
  `checkpointName` varchar(60) NOT NULL,
  `checkLatitude` varchar(255) DEFAULT NULL,
  `checkLongitude` varchar(255) DEFAULT NULL,
  `checkStatus` varchar(1) NOT NULL,
  `userName` varchar(60) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_checkpoint`
--

INSERT INTO `tb_checkpoint` (`uid`, `checkpointId`, `checkpointName`, `checkLatitude`, `checkLongitude`, `checkStatus`, `userName`, `lastUpdated`) VALUES
(6, '04dd6bda386680', 'Z', '-7.293338283383207', '112.67523109099159', '1', 'root', '2021-06-24 09:11:54'),
(7, '044eeab2ac6d80', '7', '-7.2932295333718855', '112.67509909976792', '1', 'root', '2021-06-24 09:12:20'),
(9, '0447ebb2ac6d80', '3', NULL, NULL, '1', 'root', '2021-06-14 18:49:43'),
(12, '044aeab2ac6d80', '2', NULL, NULL, '1', 'root', '2021-06-18 05:37:56'),
(13, '0456eab2ac6d80', '6', NULL, NULL, '1', 'admin', '2021-06-24 04:45:58'),
(14, '0452eab2ac6d80', '5', NULL, NULL, '1', 'admin', '2021-06-24 04:46:04'),
(15, '044b6dea5c6480', 'B', NULL, NULL, '1', 'root', '2021-06-16 06:36:44'),
(16, '04ed6aea5c6480', 'C', NULL, NULL, '0', 'root', '2021-06-25 07:50:12'),
(17, '045d32da386681', 'D', NULL, NULL, '0', 'root', '2021-06-21 02:47:24');

-- --------------------------------------------------------

--
-- Table structure for table `tb_person`
--

CREATE TABLE `tb_person` (
  `uid` int(5) NOT NULL,
  `personId` varchar(2) NOT NULL,
  `personName` varchar(60) NOT NULL,
  `userName` varchar(60) NOT NULL,
  `personStatus` varchar(1) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_person`
--

INSERT INTO `tb_person` (`uid`, `personId`, `personName`, `userName`, `personStatus`, `lastUpdated`) VALUES
(1, '1', 'yoggy', 'admin', '1', '2021-06-17 07:09:13'),
(2, '2', 'messi', 'admin', '1', '2021-06-17 07:09:17'),
(4, '3', 'amir', 'admin', '1', '2021-06-15 08:57:02'),
(6, '4', 'nanda', 'root', '1', '2021-06-29 03:33:54');

-- --------------------------------------------------------

--
-- Table structure for table `tb_phase`
--

CREATE TABLE `tb_phase` (
  `uid` int(11) NOT NULL,
  `phaseId` varchar(11) NOT NULL,
  `phaseDate` date NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_phase`
--

INSERT INTO `tb_phase` (`uid`, `phaseId`, `phaseDate`, `lastUpdated`) VALUES
(9, '1', '2021-06-17', '2021-06-16 18:23:00'),
(15, '2', '2021-06-22', '2021-06-21 20:27:57'),
(16, '3', '2021-06-22', '2021-06-21 21:27:05'),
(21, '4', '2021-06-28', '2021-06-27 19:14:03'),
(22, '5', '2021-06-28', '2021-06-28 07:55:01'),
(23, '6', '2021-07-08', '2021-07-08 02:46:49');

-- --------------------------------------------------------

--
-- Table structure for table `tb_report`
--

CREATE TABLE `tb_report` (
  `uid` int(10) NOT NULL,
  `reportId` varchar(10) NOT NULL,
  `reportLatitude` varchar(255) NOT NULL,
  `reportLongitude` varchar(255) NOT NULL,
  `activityId` varchar(10) NOT NULL,
  `personId` varchar(2) NOT NULL,
  `checkpointName` varchar(60) NOT NULL,
  `reportNote` varchar(255) DEFAULT NULL,
  `reportDate` date NOT NULL,
  `reportTime` time NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_report`
--

INSERT INTO `tb_report` (`uid`, `reportId`, `reportLatitude`, `reportLongitude`, `activityId`, `personId`, `checkpointName`, `reportNote`, `reportDate`, `reportTime`, `lastUpdated`) VALUES
(38, '1', '29', '33', '1', '1', 'D', NULL, '2021-06-17', '17:27:30', '2021-07-07 09:39:13'),
(39, '2', '29', '33', '1', '1', 'B', NULL, '2021-06-18', '08:07:38', '2021-07-07 09:39:15'),
(112, '3', '-7.2934337', '112.6752859', '3', '1', 'Z', NULL, '2021-06-22', '16:51:15', '2021-07-07 09:39:19'),
(113, '4', '-7.2934377', '112.6752874', '3', '1', 'B', NULL, '2021-06-22', '16:51:52', '2021-07-07 09:39:21'),
(114, '5', '-7.2934341', '112.6752889', '4', '1', 'B', NULL, '2021-06-22', '16:52:12', '2021-07-07 09:39:23'),
(115, '6', '-7.2934368', '112.6752859', '4', '1', 'Z', NULL, '2021-06-22', '16:52:25', '2021-07-07 09:39:25'),
(116, '7', '-7.2934271', '112.6752908', '7', '2', 'Z', NULL, '2021-06-22', '16:53:04', '2021-07-07 09:39:59'),
(117, '8', '-7.2934288', '112.6752886', '7', '2', 'D', NULL, '2021-06-22', '16:53:26', '2021-07-07 09:39:57'),
(118, '9', '-7.2934302', '112.6752902', '8', '2', 'D', NULL, '2021-06-22', '16:53:46', '2021-07-07 09:39:56'),
(119, '10', '-7.2934310', '112.6752856', '8', '2', 'B', NULL, '2021-06-22', '16:54:04', '2021-07-07 09:39:54'),
(120, '10', '-7.2934313', '112.6752864', '9', '2', 'B', NULL, '2021-06-22', '16:54:25', '2021-07-07 09:39:52'),
(121, '10', '-7.2934302', '112.6752890', '9', '2', 'Z', NULL, '2021-06-22', '16:54:42', '2021-07-07 09:39:50'),
(122, '11', '-7.2934053', '112.6753621', '11', '1', 'Z', NULL, '2021-06-28', '09:31:38', '2021-07-07 09:39:48'),
(123, '12', '-7.2934063', '112.6753321', '11', '1', '7', NULL, '2021-06-28', '09:33:26', '2021-07-07 09:39:47'),
(124, '13', '-7.2934254', '112.6753589', '12', '1', '7', NULL, '2021-06-28', '09:36:17', '2021-07-07 09:39:45'),
(125, '14', '-7.2934418', '112.6752691', '12', '1', '6', NULL, '2021-06-28', '09:38:05', '2021-07-07 09:39:43'),
(126, '15', '-7.2934177', '112.6752917', '13', '1', '6', NULL, '2021-06-28', '09:42:51', '2021-07-07 09:39:41'),
(127, '16', '-7.2934304', '112.6752887', '14', '1', '5', NULL, '2021-06-28', '09:48:16', '2021-07-07 09:39:39'),
(128, '17', '-7.2933967', '112.6753053', '14', '1', '3', NULL, '2021-06-28', '09:50:43', '2021-07-07 09:39:35'),
(129, '18', '-7.2933973', '112.6753050', '15', '1', '3', NULL, '2021-06-28', '09:54:20', '2021-07-07 09:39:33'),
(130, '19', '-7.2934121', '112.6753149', '15', '1', '2', NULL, '2021-06-28', '09:56:45', '2021-07-07 09:39:31'),
(131, '20', '-7.2934110', '112.6753509', '16', '1', '2', NULL, '2021-06-28', '10:00:40', '2021-07-08 03:39:36'),
(132, '21', '-7.2933976', '112.6753060', '16', '1', 'Z', NULL, '2021-06-28', '10:04:34', '2021-07-08 03:39:38'),
(147, '22', '-7.2934338', '112.6753116', '21', '1', 'Z', 'Trial Z ke C', '2021-07-08', '17:15:19', '2021-07-08 10:15:46'),
(148, '23', '-7.2934343', '112.6753080', '21', '1', 'C', NULL, '2021-07-08', '17:15:52', '2021-07-08 10:15:52'),
(149, '24', '-7.2934357', '112.6753072', '22', '1', 'C', 'Trial C ke D', '2021-07-08', '17:16:11', '2021-07-08 10:16:23'),
(150, '25', '-7.2934388', '112.6753084', '22', '1', 'D', NULL, '2021-07-08', '17:16:29', '2021-07-08 10:16:29'),
(151, '26', '-7.2934389', '112.6753079', '23', '1', 'D', 'Trial D ke B', '2021-07-08', '17:16:39', '2021-07-08 10:16:50'),
(152, '27', '-7.2934430', '112.6753030', '23', '1', 'B', NULL, '2021-07-08', '17:16:56', '2021-07-08 10:16:56'),
(153, '28', '-7.2934383', '112.6753042', '24', '1', 'B', 'Trial B ke Z', '2021-07-08', '17:17:07', '2021-07-08 10:17:28'),
(154, '29', '-7.2934362', '112.6753144', '24', '1', 'Z', NULL, '2021-07-08', '17:17:34', '2021-07-08 10:17:34');

-- --------------------------------------------------------

--
-- Table structure for table `tb_schedule`
--

CREATE TABLE `tb_schedule` (
  `uid` int(11) NOT NULL,
  `scheduleId` varchar(11) NOT NULL,
  `personId` varchar(2) NOT NULL,
  `activityId` varchar(10) DEFAULT NULL,
  `checkpointName` varchar(60) NOT NULL,
  `phaseId` varchar(11) NOT NULL,
  `scheduleStart` time NOT NULL,
  `scheduleEnd` time NOT NULL,
  `scheduleDate` date NOT NULL,
  `userName` varchar(60) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_schedule`
--

INSERT INTO `tb_schedule` (`uid`, `scheduleId`, `personId`, `activityId`, `checkpointName`, `phaseId`, `scheduleStart`, `scheduleEnd`, `scheduleDate`, `userName`, `lastUpdated`) VALUES
(23, '1', '1', '1', 'D', '1', '16:30:00', '17:00:00', '2021-06-17', 'root', '2021-06-30 02:38:40'),
(24, '2', '1', '2', 'B', '1', '17:00:00', '17:30:00', '2021-06-17', 'root', '2021-06-30 02:38:42'),
(32, '3', '1', '3', 'Z', '2', '10:50:00', '11:00:00', '2021-06-22', 'root', '2021-06-30 02:38:45'),
(33, '4', '1', '4', 'D', '2', '11:00:00', '11:10:00', '2021-06-22', 'root', '2021-06-30 02:38:47'),
(34, '5', '1', '5', 'B', '2', '11:10:00', '11:20:00', '2021-06-22', 'root', '2021-06-30 02:38:48'),
(36, '6', '1', '6', 'C', '2', '11:20:00', '11:30:00', '2021-06-22', 'root', '2021-06-30 02:38:50'),
(38, '7', '2', '7', 'Z', '3', '13:00:00', '13:10:00', '2021-06-22', 'root', '2021-06-30 02:38:53'),
(39, '8', '2', '8', 'C', '3', '13:15:00', '13:20:00', '2021-06-22', 'root', '2021-06-30 02:38:55'),
(40, '9', '2', '9', 'D', '3', '13:25:00', '13:35:00', '2021-06-22', 'root', '2021-06-30 02:38:58'),
(41, '10', '2', '10', 'B', '3', '13:40:00', '13:50:00', '2021-06-22', 'root', '2021-06-30 02:39:00'),
(45, '11', '1', '11', 'Z', '4', '09:30:00', '09:35:00', '2021-06-28', 'root', '2021-06-30 02:39:01'),
(47, '12', '1', '12', '7', '4', '09:36:00', '09:41:00', '2021-06-28', 'root', '2021-06-30 02:39:03'),
(48, '13', '1', '13', '6', '4', '09:42:00', '09:47:00', '2021-06-28', 'root', '2021-06-30 02:39:05'),
(49, '14', '1', '14', '5', '4', '09:48:00', '09:53:00', '2021-06-28', 'root', '2021-06-30 02:39:06'),
(50, '15', '1', '15', '3', '4', '09:54:00', '09:59:00', '2021-06-28', 'root', '2021-06-30 02:39:09'),
(52, '16', '1', '16', '2', '4', '10:00:00', '10:05:00', '2021-06-28', 'root', '2021-06-30 02:39:10'),
(53, '17', '2', '17', 'Z', '5', '15:10:00', '15:15:00', '2021-06-28', 'root', '2021-06-30 02:39:12'),
(54, '18', '2', '18', 'C', '5', '15:15:00', '15:20:00', '2021-06-28', 'root', '2021-06-30 02:39:15'),
(55, '19', '2', '19', 'D', '5', '15:20:00', '15:25:00', '2021-06-28', 'root', '2021-06-30 02:39:17'),
(56, '20', '2', '20', 'B', '5', '15:25:00', '15:30:00', '2021-06-28', 'root', '2021-06-30 02:39:19'),
(59, '21', '1', '21', 'Z', '6', '17:00:00', '17:20:00', '2021-07-08', 'root', '2021-07-08 10:15:11'),
(60, '22', '1', '22', 'C', '6', '17:50:00', '17:55:00', '2021-07-08', 'root', '2021-07-08 10:14:06'),
(61, '23', '1', '23', 'D', '6', '17:55:00', '18:00:00', '2021-07-08', 'root', '2021-07-08 10:14:14'),
(62, '24', '1', '24', 'B', '6', '18:00:00', '18:05:00', '2021-07-08', 'root', '2021-07-08 10:14:20');

-- --------------------------------------------------------

--
-- Table structure for table `tb_task`
--

CREATE TABLE `tb_task` (
  `uid` int(11) NOT NULL,
  `taskId` varchar(11) NOT NULL,
  `taskName` varchar(60) NOT NULL,
  `userName` varchar(60) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_task`
--

INSERT INTO `tb_task` (`uid`, `taskId`, `taskName`, `userName`, `lastUpdated`) VALUES
(1, '1', 'memeriksa brankas', 'root', '2021-06-29 07:54:01'),
(2, '2', 'memeriksa pintu ruangan', 'root', '2021-06-29 07:54:19'),
(4, '4', 'memeriksa lampu', 'root', '2021-06-29 07:28:10'),
(5, '5', 'memeriksa ac', 'root', '2021-06-30 08:08:55');

-- --------------------------------------------------------

--
-- Table structure for table `tb_task_list`
--

CREATE TABLE `tb_task_list` (
  `uid` int(11) NOT NULL,
  `taskId` varchar(11) NOT NULL,
  `scheduleId` varchar(11) NOT NULL,
  `taskStatus` varchar(1) NOT NULL,
  `userName` varchar(60) NOT NULL,
  `lastUpdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_task_list`
--

INSERT INTO `tb_task_list` (`uid`, `taskId`, `scheduleId`, `taskStatus`, `userName`, `lastUpdate`) VALUES
(4, '1', '20', '0', 'root', '2021-07-09 04:19:59'),
(5, '4', '20', '0', 'root', '2021-07-09 04:20:01'),
(6, '5', '20', '0', 'root', '2021-07-09 04:20:03'),
(22, '1', '21', '0', 'root', '2021-07-09 08:41:31'),
(23, '4', '21', '1', 'root', '2021-07-09 04:21:04'),
(24, '5', '21', '1', 'root', '2021-07-09 04:21:04'),
(31, '2', '22', '1', 'root', '2021-07-09 04:20:58'),
(32, '4', '22', '0', 'root', '2021-07-09 08:20:01'),
(33, '5', '22', '1', 'root', '2021-07-09 04:20:55'),
(34, '2', '23', '1', 'root', '2021-07-09 04:20:54'),
(35, '4', '23', '1', 'root', '2021-07-09 04:20:52'),
(36, '5', '23', '0', 'root', '2021-07-09 08:20:06'),
(37, '1', '24', '1', 'root', '2021-07-09 06:15:17'),
(38, '5', '24', '1', 'root', '2021-07-09 06:15:21');

-- --------------------------------------------------------

--
-- Table structure for table `tb_task_template`
--

CREATE TABLE `tb_task_template` (
  `uid` int(11) NOT NULL,
  `templateName` varchar(30) NOT NULL,
  `taskId` varchar(11) NOT NULL,
  `userName` varchar(60) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_task_template`
--

INSERT INTO `tb_task_template` (`uid`, `templateName`, `taskId`, `userName`, `lastUpdated`) VALUES
(11, 'lantai 2', '1', 'root', '2021-07-06 08:22:08'),
(12, 'lantai 2', '4', 'root', '2021-07-06 08:22:08'),
(13, 'lantai 2', '5', 'root', '2021-07-06 08:22:08'),
(14, 'default', '2', 'root', '2021-07-06 08:23:50'),
(15, 'default', '4', 'root', '2021-07-06 08:23:50'),
(16, 'default', '5', 'root', '2021-07-06 08:23:50'),
(20, 'lantai 7', '4', 'root', '2021-07-06 08:30:05'),
(21, 'lantai 7', '5', 'root', '2021-07-06 08:30:05'),
(22, 'lantai 5', '4', 'root', '2021-07-06 08:30:14');

-- --------------------------------------------------------

--
-- Table structure for table `tb_users`
--

CREATE TABLE `tb_users` (
  `uid` int(5) NOT NULL,
  `userId` varchar(5) NOT NULL,
  `userName` varchar(60) NOT NULL,
  `userPassword` varchar(255) NOT NULL,
  `userLevel` varchar(2) NOT NULL,
  `hashMobile` varchar(255) NOT NULL,
  `hashWeb` varchar(255) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_users`
--

INSERT INTO `tb_users` (`uid`, `userId`, `userName`, `userPassword`, `userLevel`, `hashMobile`, `hashWeb`, `lastUpdated`) VALUES
(1, '1', 'admin', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', '1', 'bPcYiTvs1Ny2vWtPRynp7BySuDlBYXtgNvT2D7jbV1HWDu76pn', 'PSMz3y6zDb4QwVRNPsspgvJ2HHKkmqBA9F44DGzkty0rFCKe0b', '2021-07-13 03:51:56'),
(2, '0', 'root', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '10', 'kq22tMpK0gmwI2EQSQAGaO9Vj9PrsI2J304KpTMadRPwihdzFo', 'Uzha4yYDKrHP99hpe7pgnowrVOkVc7NXu6vUmzLJLegu1Tias6', '2021-07-13 02:47:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_activity`
--
ALTER TABLE `tb_activity`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `activityId` (`activityId`);

--
-- Indexes for table `tb_checkpoint`
--
ALTER TABLE `tb_checkpoint`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `checkpointId` (`checkpointId`);

--
-- Indexes for table `tb_person`
--
ALTER TABLE `tb_person`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `personId` (`personId`);

--
-- Indexes for table `tb_phase`
--
ALTER TABLE `tb_phase`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `phaseId` (`phaseId`);

--
-- Indexes for table `tb_report`
--
ALTER TABLE `tb_report`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `tb_schedule`
--
ALTER TABLE `tb_schedule`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `scheduleId` (`scheduleId`);

--
-- Indexes for table `tb_task`
--
ALTER TABLE `tb_task`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `taskId` (`taskId`);

--
-- Indexes for table `tb_task_list`
--
ALTER TABLE `tb_task_list`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `tb_task_template`
--
ALTER TABLE `tb_task_template`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `tb_users`
--
ALTER TABLE `tb_users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `userId` (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_activity`
--
ALTER TABLE `tb_activity`
  MODIFY `uid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `tb_checkpoint`
--
ALTER TABLE `tb_checkpoint`
  MODIFY `uid` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tb_person`
--
ALTER TABLE `tb_person`
  MODIFY `uid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tb_phase`
--
ALTER TABLE `tb_phase`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `tb_report`
--
ALTER TABLE `tb_report`
  MODIFY `uid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=155;

--
-- AUTO_INCREMENT for table `tb_schedule`
--
ALTER TABLE `tb_schedule`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `tb_task`
--
ALTER TABLE `tb_task`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tb_task_list`
--
ALTER TABLE `tb_task_list`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `tb_task_template`
--
ALTER TABLE `tb_task_template`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tb_users`
--
ALTER TABLE `tb_users`
  MODIFY `uid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

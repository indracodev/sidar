<?php
include '../../config.php';
$output;

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $postHash = $_GET['hash'];
    $postDevice = $_GET['device'];

    if (isset($postHash) && !empty($postHash) && $postHash != 'undefined' &&
        isset($postDevice) && !empty($postDevice) && $postDevice != 'undefined') {
        $query;
        switch ($postDevice) {
            case 'web':
                $query = "SELECT userId FROM tb_users WHERE hashWeb = ?";
                break;
            case 'mobile':
                $query = "SELECT userId FROM tb_users WHERE hashMobile = ?";
                break;
        }
        $sqlCheck = $conn->prepare($query);
        $sqlCheck->bind_param('s', $postHash);
        $sqlCheck->execute();
        $resultCheck = $sqlCheck->get_result();
        if ($resultCheck->num_rows > 0) {
            $sql = $conn->prepare("SELECT reportId, personName, checkpointName, reportLatitude, reportLongitude, reportDate, reportTime
                FROM tb_report, tb_person, tb_checkpoint WHERE tb_report.personId = tb_person.personId AND tb_checkpoint.checkpointId = tb_report.checkpointId");
            $sql->execute();
            $result = $sql->get_result();
            if ($result->num_rows > 0) {
                $personArray = [];
                $person = new stdClass();
                while ($row = $result->fetch_assoc()) {
                    $personArray[] = (object) [
                        id => $row['reportId'],
                        person => ucfirst($row['personName']),
                        checkpoint => $row['checkpointName'],
                        location => $row['reportLatitude'].','.$row['reportLongitude'],
                        date => $row['reportDate'].' '.$row['reportTime'],
                    ];
                }
                $output->status = 'success';
                $output->person = $personArray;
                echo(json_encode($output));
            } else {
                $output->status = 'failed';
                echo(json_encode($output));
            }
        } else {
            $output->status = 'false';
            echo(json_encode($output));
        }
    } else {
        $output->status = 'error';
        echo(json_encode($output));
    }
}
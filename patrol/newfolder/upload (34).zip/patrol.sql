-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 11, 2021 at 10:11 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `patrol`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_activity`
--

CREATE TABLE `tb_activity` (
  `uid` int(10) NOT NULL,
  `activityId` varchar(10) NOT NULL,
  `personId` varchar(20) NOT NULL,
  `activityStart` datetime NOT NULL,
  `activityEnd` datetime DEFAULT NULL,
  `activityStatus` varchar(1) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_activity`
--

INSERT INTO `tb_activity` (`uid`, `activityId`, `personId`, `activityStart`, `activityEnd`, `activityStatus`, `lastUpdated`) VALUES
(11, '1', '043340ea5c6481', '2021-06-11 14:02:33', '2021-06-11 14:02:53', '1', '2021-06-11 07:02:53');

-- --------------------------------------------------------

--
-- Table structure for table `tb_checkpoint`
--

CREATE TABLE `tb_checkpoint` (
  `uid` int(2) NOT NULL,
  `checkpointId` varchar(20) NOT NULL,
  `checkpointName` varchar(60) NOT NULL,
  `checkLatitude` varchar(255) DEFAULT NULL,
  `checkLongitude` varchar(255) DEFAULT NULL,
  `checkStatus` varchar(1) NOT NULL,
  `userName` varchar(60) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_checkpoint`
--

INSERT INTO `tb_checkpoint` (`uid`, `checkpointId`, `checkpointName`, `checkLatitude`, `checkLongitude`, `checkStatus`, `userName`, `lastUpdated`) VALUES
(1, '1', 'A', NULL, NULL, '1', '', '2021-06-10 03:36:15'),
(2, '2', 'B', '-7.293358', '112.675166', '1', '', '2021-06-10 03:36:07'),
(3, '3', 'C', '-7.293307', '112.675265', '1', '', '2021-06-04 10:25:04'),
(6, '04dd6bda386680', 'Z', NULL, NULL, '0', 'admin', '2021-06-10 06:55:54'),
(7, '044eeab2ac6d80', 'G', NULL, NULL, '0', 'root', '2021-06-11 06:27:12');

-- --------------------------------------------------------

--
-- Table structure for table `tb_person`
--

CREATE TABLE `tb_person` (
  `uid` int(5) NOT NULL,
  `personId` varchar(20) NOT NULL,
  `personName` varchar(60) NOT NULL,
  `userName` varchar(60) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_person`
--

INSERT INTO `tb_person` (`uid`, `personId`, `personName`, `userName`, `lastUpdated`) VALUES
(1, '1', 'yoggy', '', '2021-05-20 06:39:10'),
(2, '2', 'messi', '', '2021-06-10 03:36:31'),
(4, 'FF:FF:FF:FF:FF:FF:FF', 'amir', 'admin', '2021-06-08 08:38:45'),
(6, '043340ea5c6481', 'nanda', 'admin', '2021-06-10 06:55:21');

-- --------------------------------------------------------

--
-- Table structure for table `tb_phase`
--

CREATE TABLE `tb_phase` (
  `uid` int(11) NOT NULL,
  `phaseId` varchar(11) NOT NULL,
  `phaseDate` date NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_phase`
--

INSERT INTO `tb_phase` (`uid`, `phaseId`, `phaseDate`, `lastUpdated`) VALUES
(1, '1', '2021-06-03', '2021-06-03 04:34:20'),
(8, '2', '2021-06-04', '2021-06-04 05:42:32');

-- --------------------------------------------------------

--
-- Table structure for table `tb_report`
--

CREATE TABLE `tb_report` (
  `uid` int(10) NOT NULL,
  `reportId` varchar(10) NOT NULL,
  `reportLatitude` varchar(255) NOT NULL,
  `reportLongitude` varchar(255) NOT NULL,
  `activityId` varchar(10) NOT NULL,
  `personId` varchar(20) NOT NULL,
  `checkpointId` varchar(20) NOT NULL,
  `reportDate` date NOT NULL,
  `reportTime` time NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_report`
--

INSERT INTO `tb_report` (`uid`, `reportId`, `reportLatitude`, `reportLongitude`, `activityId`, `personId`, `checkpointId`, `reportDate`, `reportTime`, `lastUpdated`) VALUES
(6, '1', '-7.2934014', '112.6752677', '1', '043340ea5c6481', '044eeab2ac6d80', '2021-06-11', '14:02:33', '2021-06-11 07:02:33'),
(7, '2', '-7.2934041', '112.6752675', '1', '043340ea5c6481', '04dd6bda386680', '2021-06-11', '14:02:53', '2021-06-11 07:02:53');

-- --------------------------------------------------------

--
-- Table structure for table `tb_schedule`
--

CREATE TABLE `tb_schedule` (
  `uid` int(11) NOT NULL,
  `scheduleId` varchar(11) NOT NULL,
  `personId` varchar(5) NOT NULL,
  `checkpointName` varchar(60) NOT NULL,
  `phaseId` varchar(11) NOT NULL,
  `scheduleStart` time NOT NULL,
  `scheduleEnd` time NOT NULL,
  `scheduleDate` date NOT NULL,
  `userName` varchar(60) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_schedule`
--

INSERT INTO `tb_schedule` (`uid`, `scheduleId`, `personId`, `checkpointName`, `phaseId`, `scheduleStart`, `scheduleEnd`, `scheduleDate`, `userName`, `lastUpdated`) VALUES
(1, '1', '1', 'A', '1', '08:00:00', '09:00:00', '2021-06-03', 'admin', '2021-06-04 04:28:08'),
(2, '2', '2', 'B', '1', '09:00:00', '10:00:00', '2021-06-03', 'admin', '2021-06-04 06:18:21'),
(3, '3', '1', 'C', '1', '11:00:00', '12:00:00', '2021-06-03', 'admin', '2021-06-04 04:27:51'),
(4, '4', '2', 'D', '1', '10:00:00', '11:00:00', '2021-06-03', 'admin', '2021-06-04 06:17:48'),
(7, '5', '1', 'A', '2', '08:00:00', '09:00:00', '2021-06-04', 'admin', '2021-06-04 05:42:57');

-- --------------------------------------------------------

--
-- Table structure for table `tb_users`
--

CREATE TABLE `tb_users` (
  `uid` int(5) NOT NULL,
  `userId` varchar(5) NOT NULL,
  `userName` varchar(60) NOT NULL,
  `userPassword` varchar(255) NOT NULL,
  `userLevel` varchar(2) NOT NULL,
  `hashMobile` varchar(255) NOT NULL,
  `hashWeb` varchar(255) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_users`
--

INSERT INTO `tb_users` (`uid`, `userId`, `userName`, `userPassword`, `userLevel`, `hashMobile`, `hashWeb`, `lastUpdated`) VALUES
(1, '1', 'admin', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', '1', 'bPcYiTvs1Ny2vWtPRynp7BySuDlBYXtgNvT2D7jbV1HWDu76pn', 'CKD6D3hQCP8KtinlJejS276qOpDEJwuYwCsHX063wR6WxlRJpx', '2021-06-10 06:51:12'),
(2, '0', 'root', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '10', 'SrLnGj57NXbuB5aNAf5xBmiHLl38a3UoxwLCwMvm0rUYIYn3Hb', 'fFQ5d4uaYFgAkRDqiFTIDnDyOOoEeRngZLaxifFRvU2cXtVcjE', '2021-06-11 07:14:45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_activity`
--
ALTER TABLE `tb_activity`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `activityId` (`activityId`);

--
-- Indexes for table `tb_checkpoint`
--
ALTER TABLE `tb_checkpoint`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `checkpointId` (`checkpointId`);

--
-- Indexes for table `tb_person`
--
ALTER TABLE `tb_person`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `personId` (`personId`);

--
-- Indexes for table `tb_phase`
--
ALTER TABLE `tb_phase`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `phaseId` (`phaseId`);

--
-- Indexes for table `tb_report`
--
ALTER TABLE `tb_report`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `tb_schedule`
--
ALTER TABLE `tb_schedule`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `scheduleId` (`scheduleId`);

--
-- Indexes for table `tb_users`
--
ALTER TABLE `tb_users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `userId` (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_activity`
--
ALTER TABLE `tb_activity`
  MODIFY `uid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tb_checkpoint`
--
ALTER TABLE `tb_checkpoint`
  MODIFY `uid` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tb_person`
--
ALTER TABLE `tb_person`
  MODIFY `uid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tb_phase`
--
ALTER TABLE `tb_phase`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tb_report`
--
ALTER TABLE `tb_report`
  MODIFY `uid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tb_schedule`
--
ALTER TABLE `tb_schedule`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tb_users`
--
ALTER TABLE `tb_users`
  MODIFY `uid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

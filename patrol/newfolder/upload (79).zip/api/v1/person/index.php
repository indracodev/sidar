<?php
include '../../config.php';
$output;

//REMOVE PERSON
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    parse_str(file_get_contents("php://input"), $_DELETE);
    $personId = $_DELETE['id'];
    $userHash = $_DELETE['hash'];

    if (
        isset($personId) && !empty($personId) && $personId != 'undefined' &&
        isset($userHash) && !empty($userHash) && $userHash != 'undefined'
    ) {
        $sql = $conn->prepare(
            "SELECT userName 
            FROM tb_users 
            WHERE hashWeb = ?"
        );
        $sql->bind_param('s', $userHash);
        $sql->execute();
        $result = $sql->get_result();
        $userName;
        while ($row = $result->fetch_assoc()) {
            $userName = $row['userName'];
        }

        $sql = $conn->prepare(
            "SELECT personName 
            FROM tb_person 
            WHERE personId = ?"
        );
        $sql->bind_param('s', $personId);
        $sql->execute();
        $result = $sql->get_result();
        $personName;
        while ($row = $result->fetch_assoc()) {
            $personName = $row['personName'];
        }

        try {
            $conn->begin_transaction();

            $newName = $personName . ' DELETED';
            $sql = $conn->prepare(
                "UPDATE tb_person 
                SET isDeleted = '1', personName = ?, userName = ? 
                WHERE personId = ?"
            );
            $sql->bind_param('sss', $newName, $userName, $personId);
            if ($sql->execute() === FALSE) throw new Exception('Statement UPDATE Failed');
            
        } catch (Exception $e) {
            $output->status = 'failed';
            echo (json_encode($output));
            $conn->rollback();
            exit();
        } finally {
            $output->status = 'success';
            echo (json_encode($output));
            $conn->commit();
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    parse_str(file_get_contents("php://input"), $_PUT);
    $userHash = $_PUT['hash'];
    $action = $_GET['action'];

    if (isset($userHash) && !empty($userHash) && $userHash != 'undefined') {
        $sql = $conn->prepare(
            "SELECT userName 
            FROM tb_users 
            WHERE hashWeb = ?"
        );
        $sql->bind_param('s', $userHash);
        $sql->execute();
        $result = $sql->get_result();
        $userName;
        while ($row = $result->fetch_assoc()) {
            $userName = $row['userName'];
        }

        switch ($action) {
            //EDIT PERSON NAME
            case 'person':
                $personName = strtolower($_PUT['person']);
                $personId = $_PUT['id'];

                try {
                    $conn->begin_transaction();
    
                    $sql = $conn->prepare(
                        "UPDATE tb_person 
                        SET personName = ?, userName = ? 
                        WHERE personId = ?"
                    );
                    $sql->bind_param('sss', $personName, $userName, $personId);
                    if ($sql->execute() === FALSE) throw new Exception('Statement UPDATE Failed');

                } catch (Exception $e) {
                    $output->status = 'failed';
                    echo (json_encode($output));
                    $conn->rollback();
                    exit();
                } finally {
                    $output->status = 'success';
                    echo (json_encode($output));
                    $conn->commit();
                }
                break;
            //EDIT MAPPING NAME
            case 'mapping':
                $mappingName = strtolower($_PUT['mapping']);
                $mappingId = $_PUT['id'];

                try {
                    $conn->begin_transaction();

                    $sql = $conn->prepare(
                        "UPDATE tb_person_mapping 
                        SET mappingName = ?, userName = ? 
                        WHERE mappingId = ?"
                    );
                    $sql->bind_param('sss', $mappingName, $userName, $mappingId);
                    if ($sql->execute() === FALSE) throw new Exception('Statement UPDATE Failed');

                } catch (Exception $e) {
                    $output->status = 'failed';
                    echo (json_encode($output));
                    $conn->rollback();
                    exit();
                } finally {
                    $output->status = 'success';
                    echo (json_encode($output));
                    $conn->commit();
                }
                break;
            default:
                $output->status = 'error';
                echo (json_encode($output));
                break;
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = strtolower($_POST['name']);
    $userHash = $_POST['hash'];
    $postDevice = $_GET['device'];

    switch ($postDevice) {
        //ADD PERSON
        case 'web':
            if (
                isset($name) && !empty($name) && $name != 'undefined' &&
                isset($userHash) && !empty($userHash) && $userHash != 'undefined'
            ) {
                $sql = $conn->prepare(
                    "SELECT userName
                    FROM tb_users 
                    WHERE hashWeb = ?"
                );
                $sql->bind_param('s', $userHash);
                $sql->execute();
                $result = $sql->get_result();
                $userName;
                while ($row = $result->fetch_assoc()) {
                    $userName = $row['userName'];
                }

                $sql = $conn->prepare(
                    "SELECT personName 
                    FROM tb_person 
                    WHERE personName = ?"
                );
                $sql->bind_param('s', $name);
                $sql->execute();
                $result = $sql->get_result();
                if ($result->num_rows > 0) {
                    $output->status = 'exist';
                    echo (json_encode($output));
                } else {
                    $sql = $conn->prepare(
                        "SELECT personId 
                        FROM tb_person 
                        ORDER BY uid DESC LIMIT 1"
                    );
                    $sql->execute();
                    $result = $sql->get_result();
                    $personId = '1';
                    while ($row = $result->fetch_assoc()) {
                        $personId = (int)$row['personId'] + 1;
                    }

                    try {
                        $conn->begin_transaction();

                        $sql = $conn->prepare(
                            "INSERT INTO tb_person (personId, personName, isDeleted, userName) 
                            VALUES (?, ?, '0', ?)"
                        );
                        $sql->bind_param('iss', $personId, $name, $userName);
                        if ($sql->execute() === FALSE) throw new Exception('Statement INSERT Failed');

                    } catch (Exception $e) {
                        $output->status = 'failed';
                        echo (json_encode($output));
                        $conn->rollback();
                        exit();
                    } finally {
                        $output->status = 'success';
                        echo (json_encode($output));
                        $conn->commit();
                    }
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
        //ADD MAPPING
        case 'mobile':
            $mappingTag = $_POST['id'];

            if (
                isset($name) && !empty($name) && $name != 'undefined' &&
                isset($userHash) && !empty($userHash) && $userHash != 'undefined' &&
                isset($mappingTag) && !empty($mappingTag) && $mappingTag != 'undefined'
            ) {
                $sql = $conn->prepare(
                    "SELECT userName 
                    FROM tb_users 
                    WHERE hashMobile = ?"
                );
                $sql->bind_param('s', $userHash);
                $sql->execute();
                $result = $sql->get_result();
                $userName;
                while ($row = $result->fetch_assoc()) {
                    $userName = $row['userName'];
                }

                $sql = $conn->prepare(
                    "SELECT mappingId 
                    FROM tb_person_mapping 
                    WHERE mappingTag = ?"
                );
                $sql->bind_param('s', $mappingTag);
                $sql->execute();
                $result = $sql->get_result();
                if ($result->num_rows > 0) {
                    $output->status = 'exist';
                    echo (json_encode($output));
                } else {
                    $sql = $conn->prepare(
                        "SELECT mappingId 
                        FROM tb_person_mapping 
                        ORDER BY uid DESC LIMIT 1"
                    );
                    $sql->execute();
                    $result = $sql->get_result();
                    $mappingId = '1';
                    while ($row = $result->fetch_assoc()) {
                        $mappingId = (int)$row['mappingId'] + 1;
                    }

                    try {
                        $conn->begin_transaction();

                        $sql = $conn->prepare(
                            "INSERT into tb_person_mapping (mappingId, mappingTag, mappingName, username) 
                            VALUES (?, ?, ?, ?)"
                        );
                        $sql->bind_param('ssss', $mappingId, $mappingTag, $name, $userName);
                        if ($sql->execute() === FALSE) throw new Exception('Statement INSERT Failed');

                    } catch (Exception $e) {
                        $output->status = 'failed';
                        echo (json_encode($output));
                        $conn->rollback();
                        exit();
                    } finally {
                        $output->status = 'success';
                        echo (json_encode($output));
                        $conn->commit();
                    }
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $userHash = $_GET['hash'];
    $action = $_GET['action'];

    switch ($action) {
        //GET PERSON LIST
        case 'person':
            $postDevice = $_GET['device'];

            if (isset($userHash) && !empty($userHash) && $userHash != 'undefined' &&
                isset($postDevice) && !empty($postDevice) && $postDevice != 'undefined') {
                $sql;
                switch ($postDevice) {
                    case 'web':
                        $sql = $conn->prepare(
                            "SELECT userId 
                            FROM tb_users 
                            WHERE hashWeb = ?"
                        );
                        break;
                    case 'mobile':
                        $sql = $conn->prepare(
                            "SELECT userId 
                            FROM tb_users 
                            WHERE hashMobile = ?"
                        );
                        break;
                }
                
                $sql->bind_param('s', $userHash);
                $sql->execute();
                $result = $sql->get_result();
                if ($result->num_rows > 0) {
                    $sql = $conn->prepare(
                        "SELECT personName, personId, lastUpdated 
                        FROM tb_person 
                        WHERE isDeleted = '0'
                        ORDER BY personName ASC"
                    );
                    $sql->execute();
                    $result = $sql->get_result();
                    $personArray = [];
                    while ($row = $result->fetch_assoc()) {
                        $personArray[] = (object) [
                            'ref' => $row['personId'],
                            'name' => ucfirst($row['personName']),
                            'update' => date('d/m/Y (H:i)', strtotime($row['lastUpdated'])),
                        ];
                    }

                    $sql = $conn->prepare(
                        "SELECT mappingId, mappingName, mappingTag, lastUpdated
                        FROM tb_person_mapping
                        ORDER BY mappingName ASC"
                    );
                    $sql->execute();
                    $result = $sql->get_result();
                    $mappingArray = [];
                    while ($row = $result->fetch_assoc()) {
                        $mappingArray[] = (object) [
                            'id' => $row['mappingId'],
                            'name' => ucfirst($row['mappingName']),
                            'tag' => strtoupper($row['mappingTag']),
                            'update' => date('d/m/Y (H:i)', strtotime($row['lastUpdated']))
                        ];
                    }

                    $output->status = 'success';
                    $output->person = $personArray;
                    $output->mapping = $mappingArray;
                    echo (json_encode($output));
                } else {
                    $output->status = 'error';
                    echo (json_encode($output));
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
        //GET MAPPING LIST
        case 'mapping':
            if (isset($userHash) && !empty($userHash) && $userHash != 'undefined') {
                $sql = $conn->prepare(
                    "SELECT userId 
                    FROM tb_users 
                    WHERE hashWeb = ?"
                );
                $sql->bind_param('s', $userHash);
                $sql->execute();
                $result = $sql->get_result();
                if ($result->num_rows > 0) {
                    $sql = $conn->prepare(
                        "SELECT mappingId, mappingName, lastUpdated 
                        FROM tb_person_mapping
                        ORDER BY mappingName ASC"
                    );
                    $sql->execute();
                    $result = $sql->get_result();
                    $mappingArray = [];
                    while ($row = $result->fetch_assoc()) {

                        $mappingArray[] = (object) [
                            'id' => $row['mappingId'],
                            'name' => ucfirst($row['mappingName']),
                            'update' => date('d/m/Y (H:i)', strtotime($row['lastUpdated'])),
                        ];
                    }
                    $output->status = 'success';
                    $output->mapping = $mappingArray;
                    echo (json_encode($output));
                } else {
                    $output->status = 'error';
                    echo (json_encode($output));
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
        //GET MAPPING NAME
        case 'check':
            $mappingTag = $_GET['id'];

            if (isset($userHash) && !empty($userHash) && $userHash != 'undefined' &&
                isset($mappingTag) && !empty($mappingTag) && $mappingTag != 'undefined') {
                $sql = $conn->prepare(
                    "SELECT userId 
                    FROM tb_users 
                    WHERE hashMobile = ?"
                );
                $sql->bind_param('s', $userHash);
                $sql->execute();
                $result = $sql->get_result();
                if ($result->num_rows > 0) {
                    $sql = $conn->prepare(
                        "SELECT mappingName 
                        FROM tb_person_mapping 
                        WHERE mappingTag = ?"
                    );
                    $sql->bind_param('s', $mappingTag);
                    $sql->execute();
                    $result = $sql->get_result();
                    while ($row = $result->fetch_assoc()) {
                        $output->status = 'success';
                        $output->mapping = ucfirst($row['mappingName']);
                        echo (json_encode($output));
                    }
                } else {
                    $output->status = 'error';
                    echo (json_encode($output));
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
        case 'list':
            $sql = $conn->prepare(
                "SELECT mappingId, mappingTag
                FROM tb_person_mapping"
            );
            $sql->execute();
            $getMapping = $sql->get_result();
            $mapping = [];
            while ($row = $getMapping->fetch_assoc()) {

                $mapping[] = (object) [
                    'mappingId' => $row['mappingId'],
                    'mappingTag' => $row['mappingTag']
                ];

            }
            $output->status = 'success';
            $output->mapping = $mapping;
            echo (json_encode($output));
            break;
        default:
            $output->status = 'error';
            echo (json_encode($output));
            break;
    }
}

-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 22, 2021 at 12:13 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `guard`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_activity`
--

CREATE TABLE `tb_activity` (
  `uid` int(10) NOT NULL,
  `activityId` varchar(10) NOT NULL,
  `personId` varchar(2) DEFAULT NULL,
  `scheduleId` varchar(11) DEFAULT NULL,
  `checkpointStart` varchar(60) DEFAULT NULL,
  `checkpointEnd` varchar(60) DEFAULT NULL,
  `activityStart` datetime DEFAULT NULL,
  `activityEnd` datetime DEFAULT NULL,
  `activityStatus` varchar(1) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_activity`
--

INSERT INTO `tb_activity` (`uid`, `activityId`, `personId`, `scheduleId`, `checkpointStart`, `checkpointEnd`, `activityStart`, `activityEnd`, `activityStatus`, `lastUpdated`) VALUES
(41, '1', '1', '1', 'D', 'B', '2021-06-17 16:16:59', '2021-06-17 16:56:44', '1', '2021-06-17 02:56:44'),
(42, '2', '1', '2', 'B', 'A', '2021-06-17 17:21:25', '2021-06-17 17:22:42', '1', '2021-06-17 18:18:35'),
(51, '3', '1', '3', 'Z', 'B', '2021-06-22 16:51:15', '2021-06-22 16:51:51', '1', '2021-06-22 09:51:51'),
(53, '4', '1', '4', 'B', 'Z', '2021-06-22 16:52:11', '2021-06-22 16:52:25', '1', '2021-06-22 09:52:25'),
(54, '5', '1', '5', NULL, NULL, NULL, NULL, '-', '2021-06-22 09:52:25'),
(55, '6', '1', '6', NULL, NULL, NULL, NULL, '-', '2021-06-22 09:52:25'),
(58, '7', '2', '7', 'Z', 'D', '2021-06-22 16:53:04', '2021-06-22 16:53:26', '1', '2021-06-22 09:53:26'),
(59, '8', '2', '8', 'D', 'B', '2021-06-22 16:53:46', '2021-06-22 16:54:04', '1', '2021-06-22 09:54:04'),
(60, '9', '2', '9', 'B', 'Z', '2021-06-22 16:54:25', '2021-06-22 16:54:42', '1', '2021-06-22 09:54:42'),
(61, '10', '2', '10', NULL, NULL, NULL, NULL, '-', '2021-06-22 09:54:42');

-- --------------------------------------------------------

--
-- Table structure for table `tb_checkpoint`
--

CREATE TABLE `tb_checkpoint` (
  `uid` int(2) NOT NULL,
  `checkpointId` varchar(20) NOT NULL,
  `checkpointName` varchar(60) NOT NULL,
  `checkLatitude` varchar(255) DEFAULT NULL,
  `checkLongitude` varchar(255) DEFAULT NULL,
  `checkStatus` varchar(1) NOT NULL,
  `userName` varchar(60) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_checkpoint`
--

INSERT INTO `tb_checkpoint` (`uid`, `checkpointId`, `checkpointName`, `checkLatitude`, `checkLongitude`, `checkStatus`, `userName`, `lastUpdated`) VALUES
(6, '04dd6bda386680', 'Z', NULL, NULL, '1', 'root', '2021-06-22 03:37:17'),
(7, '044eeab2ac6d80', '7', NULL, NULL, '1', 'root', '2021-06-14 18:49:37'),
(9, '0447ebb2ac6d80', '3', NULL, NULL, '1', 'root', '2021-06-14 18:49:43'),
(12, '044aeab2ac6d80', '2', NULL, NULL, '1', 'root', '2021-06-18 05:37:56'),
(13, '0456eab2ac6d80', '6', NULL, NULL, '0', 'admin', '2021-06-14 18:56:29'),
(14, '0452eab2ac6d80', '5', NULL, NULL, '0', 'admin', '2021-06-14 18:57:06'),
(15, '044b6dea5c6480', 'B', NULL, NULL, '1', 'root', '2021-06-16 06:36:44'),
(16, '04ed6aea5c6480', 'C', NULL, NULL, '1', 'root', '2021-06-16 06:36:46'),
(17, '045d32da386681', 'D', NULL, NULL, '0', 'root', '2021-06-21 02:47:24');

-- --------------------------------------------------------

--
-- Table structure for table `tb_person`
--

CREATE TABLE `tb_person` (
  `uid` int(5) NOT NULL,
  `personId` varchar(2) NOT NULL,
  `personName` varchar(60) NOT NULL,
  `userName` varchar(60) NOT NULL,
  `personStatus` varchar(1) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_person`
--

INSERT INTO `tb_person` (`uid`, `personId`, `personName`, `userName`, `personStatus`, `lastUpdated`) VALUES
(1, '1', 'yoggy', 'admin', '1', '2021-06-17 07:09:13'),
(2, '2', 'messi', 'admin', '1', '2021-06-17 07:09:17'),
(4, '3', 'amir', 'admin', '1', '2021-06-15 08:57:02'),
(6, '4', 'nanda', 'admin', '1', '2021-06-15 09:00:55');

-- --------------------------------------------------------

--
-- Table structure for table `tb_phase`
--

CREATE TABLE `tb_phase` (
  `uid` int(11) NOT NULL,
  `phaseId` varchar(11) NOT NULL,
  `phaseDate` date NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_phase`
--

INSERT INTO `tb_phase` (`uid`, `phaseId`, `phaseDate`, `lastUpdated`) VALUES
(9, '1', '2021-06-17', '2021-06-17 01:23:00'),
(15, '2', '2021-06-22', '2021-06-22 03:27:57'),
(16, '3', '2021-06-22', '2021-06-22 04:27:05');

-- --------------------------------------------------------

--
-- Table structure for table `tb_report`
--

CREATE TABLE `tb_report` (
  `uid` int(10) NOT NULL,
  `reportId` varchar(10) NOT NULL,
  `reportLatitude` varchar(255) NOT NULL,
  `reportLongitude` varchar(255) NOT NULL,
  `activityId` varchar(10) NOT NULL,
  `personId` varchar(2) NOT NULL,
  `checkpointName` varchar(60) NOT NULL,
  `reportDate` date NOT NULL,
  `reportTime` time NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_report`
--

INSERT INTO `tb_report` (`uid`, `reportId`, `reportLatitude`, `reportLongitude`, `activityId`, `personId`, `checkpointName`, `reportDate`, `reportTime`, `lastUpdated`) VALUES
(38, '1', '29', '33', '1', '1', 'D', '2021-06-17', '17:27:30', '2021-06-17 03:27:30'),
(39, '2', '29', '33', '1', '1', 'B', '2021-06-18', '08:07:38', '2021-06-17 18:07:38'),
(112, '3', '-7.2934337', '112.6752859', '3', '1', 'Z', '2021-06-22', '16:51:15', '2021-06-22 09:51:15'),
(113, '4', '-7.2934377', '112.6752874', '3', '1', 'B', '2021-06-22', '16:51:52', '2021-06-22 09:51:52'),
(114, '5', '-7.2934341', '112.6752889', '4', '1', 'B', '2021-06-22', '16:52:12', '2021-06-22 09:52:12'),
(115, '6', '-7.2934368', '112.6752859', '4', '1', 'Z', '2021-06-22', '16:52:25', '2021-06-22 09:52:25'),
(116, '7', '-7.2934271', '112.6752908', '7', '2', 'Z', '2021-06-22', '16:53:04', '2021-06-22 09:53:04'),
(117, '8', '-7.2934288', '112.6752886', '7', '2', 'D', '2021-06-22', '16:53:26', '2021-06-22 09:53:26'),
(118, '9', '-7.2934302', '112.6752902', '8', '2', 'D', '2021-06-22', '16:53:46', '2021-06-22 09:53:46'),
(119, '10', '-7.2934310', '112.6752856', '8', '2', 'B', '2021-06-22', '16:54:04', '2021-06-22 09:54:04'),
(120, '10', '-7.2934313', '112.6752864', '9', '2', 'B', '2021-06-22', '16:54:25', '2021-06-22 09:54:25'),
(121, '10', '-7.2934302', '112.6752890', '9', '2', 'Z', '2021-06-22', '16:54:42', '2021-06-22 09:54:42');

-- --------------------------------------------------------

--
-- Table structure for table `tb_schedule`
--

CREATE TABLE `tb_schedule` (
  `uid` int(11) NOT NULL,
  `scheduleId` varchar(11) NOT NULL,
  `personId` varchar(2) NOT NULL,
  `activityId` varchar(10) DEFAULT NULL,
  `checkpointName` varchar(60) NOT NULL,
  `phaseId` varchar(11) NOT NULL,
  `scheduleStart` time NOT NULL,
  `scheduleEnd` time NOT NULL,
  `scheduleDate` date NOT NULL,
  `userName` varchar(60) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_schedule`
--

INSERT INTO `tb_schedule` (`uid`, `scheduleId`, `personId`, `activityId`, `checkpointName`, `phaseId`, `scheduleStart`, `scheduleEnd`, `scheduleDate`, `userName`, `lastUpdated`) VALUES
(23, '1', '1', '1', 'D', '1', '16:30:00', '17:00:00', '2021-06-17', 'root', '2021-06-17 18:10:27'),
(24, '2', '1', '2', 'B', '1', '17:00:00', '17:30:00', '2021-06-17', 'root', '2021-06-17 02:13:33'),
(32, '3', '1', '3', 'Z', '2', '10:50:00', '11:00:00', '2021-06-22', 'root', '2021-06-22 03:37:24'),
(33, '4', '1', '4', 'D', '2', '11:00:00', '11:10:00', '2021-06-22', 'root', '2021-06-22 03:32:13'),
(34, '5', '1', '5', 'B', '2', '11:10:00', '11:20:00', '2021-06-22', 'root', '2021-06-22 03:32:19'),
(36, '6', '1', '6', 'C', '2', '11:20:00', '11:30:00', '2021-06-22', 'root', '2021-06-22 03:32:23'),
(38, '7', '2', '7', 'Z', '3', '13:00:00', '13:10:00', '2021-06-22', 'root', '2021-06-22 04:28:42'),
(39, '8', '2', '8', 'C', '3', '13:15:00', '13:20:00', '2021-06-22', 'root', '2021-06-22 04:28:26'),
(40, '9', '2', '9', 'D', '3', '13:25:00', '13:35:00', '2021-06-22', 'root', '2021-06-22 04:29:07'),
(41, '10', '2', '10', 'B', '3', '13:40:00', '13:50:00', '2021-06-22', 'root', '2021-06-22 04:29:29');

-- --------------------------------------------------------

--
-- Table structure for table `tb_users`
--

CREATE TABLE `tb_users` (
  `uid` int(5) NOT NULL,
  `userId` varchar(5) NOT NULL,
  `userName` varchar(60) NOT NULL,
  `userPassword` varchar(255) NOT NULL,
  `userLevel` varchar(2) NOT NULL,
  `hashMobile` varchar(255) NOT NULL,
  `hashWeb` varchar(255) NOT NULL,
  `lastUpdated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_users`
--

INSERT INTO `tb_users` (`uid`, `userId`, `userName`, `userPassword`, `userLevel`, `hashMobile`, `hashWeb`, `lastUpdated`) VALUES
(1, '1', 'admin', '5994471abb01112afcc18159f6cc74b4f511b99806da59b3caf5a9c173cacfc5', '1', 'bPcYiTvs1Ny2vWtPRynp7BySuDlBYXtgNvT2D7jbV1HWDu76pn', 'F1TAj8z2pLW4btgBGt9wtZS7gu7RvO5a0st7fkHzhZD3r9VkpC', '2021-06-18 04:10:15'),
(2, '0', 'root', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '10', 'egMbF6UcQcO6ifnUPlGMjSWUOmzDTOm3naqiI4UfqUi2UzBwit', 'YSEJSMT4mAm0XI3AHFxQmIOqo5G0iPUHGr1Bup0nwjtyKUN3ey', '2021-06-22 03:34:20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_activity`
--
ALTER TABLE `tb_activity`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `activityId` (`activityId`);

--
-- Indexes for table `tb_checkpoint`
--
ALTER TABLE `tb_checkpoint`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `checkpointId` (`checkpointId`);

--
-- Indexes for table `tb_person`
--
ALTER TABLE `tb_person`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `personId` (`personId`);

--
-- Indexes for table `tb_phase`
--
ALTER TABLE `tb_phase`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `phaseId` (`phaseId`);

--
-- Indexes for table `tb_report`
--
ALTER TABLE `tb_report`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `tb_schedule`
--
ALTER TABLE `tb_schedule`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `scheduleId` (`scheduleId`);

--
-- Indexes for table `tb_users`
--
ALTER TABLE `tb_users`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `userId` (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_activity`
--
ALTER TABLE `tb_activity`
  MODIFY `uid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `tb_checkpoint`
--
ALTER TABLE `tb_checkpoint`
  MODIFY `uid` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tb_person`
--
ALTER TABLE `tb_person`
  MODIFY `uid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tb_phase`
--
ALTER TABLE `tb_phase`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tb_report`
--
ALTER TABLE `tb_report`
  MODIFY `uid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=122;

--
-- AUTO_INCREMENT for table `tb_schedule`
--
ALTER TABLE `tb_schedule`
  MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `tb_users`
--
ALTER TABLE `tb_users`
  MODIFY `uid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

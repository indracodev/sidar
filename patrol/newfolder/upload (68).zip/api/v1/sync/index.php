<?php
include '../../config.php';
$do = $_GET["action"];
$status = "failed";
$pesan = "";
$daJson = array();

if($do == "receive"){
  if(!isset($_POST["activityId"])){
    $pesan = "Sorry! no activity detected";
  } else if(!isset($_POST["personId"])){
    $pesan = "Sorry! no person detected";
  } else if(!isset($_POST["scheduleId"])){
    $pesan = "Sorry! no schedule detected";
  } else if(!isset($_POST["checkpointStart"])){
    $pesan = "Sorry! no checkpoint start detected";
  } else if(!isset($_POST["checkpointEnd"])){
    $pesan = "Sorry! no checkpoint end detected";
  } else if(!isset($_POST["activityStart"])){
    $pesan = "Sorry! no activity start detected";
  } else if(!isset($_POST["activityEnd"])){
    $pesan = "Sorry! no activity end detected";
  } else if(!isset($_POST["activityStatus"])){
    $pesan = "Sorry! no activity status detected";
  } else if(!isset($_POST["latitudeStart"])){
    $pesan = "Sorry! no latitude start detected";
  } else if(!isset($_POST["longitudeStart"])){
    $pesan = "Sorry! no longitude start detected";
  } else if(!isset($_POST["latitudeEnd"])){
    $pesan = "Sorry! no latitude end detected";
  } else if(!isset($_POST["longitudeEnd"])){
    $pesan = "Sorry! no longitude end detected";
  } else if(!isset($_POST["reportNote"])){
    $pesan = "Sorry! no report note detected";
  } else if(!isset($_POST["reportDate"])){
    $pesan = "Sorry! no report date detected";
  } else if(!isset($_POST["reportTime"])){
    $pesan = "Sorry! no report time detected";
  } else if(!isset($_POST["tasks"])){
    $pesan = "Sorry! no tasks detected";
  } else {
    //Table activity
    $activityId         = $_POST["activityId"];
    $personId           = $_POST["personId"];
    $scheduleId         = $_POST["scheduleId"];
    $checkpointStart    = $_POST["checkpointStart"]; //NULL
    $checkpointEnd      = $_POST["checkpointEnd"]; //NULL
    $activityStart      = $_POST["activityStart"]; //NULL
    $activityEnd        = $_POST["activityEnd"]; //NULL
    $activityStatus     = $_POST["activityStatus"]; //NULL
    //Table Report
    $latitudeStart      = $_POST["latitudeStart"]; //NULL
    $longitudeStart     = $_POST["longitudeStart"]; //NULL
    $latitudeEnd        = $_POST["latitudeEnd"]; //NULL
    $longitudeEnd       = $_POST["longitudeEnd"]; //NULL
    $reportNote         = addslashes($_POST["reportNote"]); //NULL
    $reportDate         = $_POST["reportDate"]; //NULL
    $reportTime         = $_POST["reportTime"]; //NULL
    //Table Tasklist
    $tasks              = addslashes($_POST["tasks"]); //NULL

    if($activityId == ""){
      $pesan = "Sorry! activity cannot be empty!";
    } else if($personId == ""){
      $pesan = "Sorry! person cannot be empty!";
    } else if($scheduleId == ""){
      $pesan = "Sorry! schedule cannot be empty!";
    } else {
      //insert activity table

      $getActivity = $conn->query("SELECT * FROM tb_activity WHERE activityId = '".$activityId."' AND personId = '".$personId."' ");
      $countActivity = $getActivity->num_rows;
      if($countActivity == 0){
        $pesan = "Sorry! no activities found";
      } else {
        if($activityStatus == "1"){

          if ($activityStart != '0000-00-00 00:00:00' && $activityEnd != '0000-00-00 00:00:00') {
            $conn->query("UPDATE tb_activity SET
              checkpointStart = '".$checkpointStart."',
              checkpointEnd = '".$checkpointEnd."',
              activityStart = '".$activityStart."',
              activityEnd = '".$activityEnd."',
              activityStatus = '".$activityStatus."'
              WHERE activityId = '".$activityId."' AND personId = '".$personId."' ");
          } else {
            $conn->query("UPDATE tb_activity SET
              checkpointStart = NULL,
              checkpointEnd = NULL,
              activityStart = NULL,
              activityEnd = NULL,
              activityStatus = '0'
              WHERE activityId = '".$activityId."' AND personId = '".$personId."' ");
          }

          //Get Recent report table
          $getRecent = $conn->query("SELECT * FROM tb_report ORDER BY uid DESC LIMIT 1");
          $countRecent = $getRecent->num_rows;
          if($countRecent != 1){
            $reportId = 1;
          } else {
            $fetchRecent = $getRecent->fetch_assoc();
            $recentUID = $fetchRecent["reportId"];
            $reportId = $recentUID + 1;
          }
          //Get same activity
          $getSame = $conn->query("SELECT * FROM tb_report WHERE activityId = '".$activityId."' AND personId = '".$personId."' ");
          $countSame = $getSame->num_rows;
          if($countSame == 0){
            $latitudeVal = $latitudeStart;
            $longitudeVal = $longitudeStart;
            $checkpointName = $checkpointStart;
            //Insert report table
            $conn->query("INSERT INTO tb_report VALUES(
              NULL,
              '".$reportId."',
              '".$latitudeVal."',
              '".$longitudeVal."',
              '".$activityId."',
              '".$personId."',
              '".$checkpointName."',
              '".$reportNote."',
              '".$reportDate."',
              '".$reportTime."',
              NOW()
            )");

            $latitudeVal = $latitudeEnd;
            $longitudeVal = $longitudeEnd;
            $checkpointName = $checkpointEnd;
            //Insert report table
            $conn->query("INSERT INTO tb_report VALUES(
              NULL,
              '".$reportId."',
              '".$latitudeVal."',
              '".$longitudeVal."',
              '".$activityId."',
              '".$personId."',
              '".$checkpointName."',
              NULL,
              '".$reportDate."',
              '".$reportTime."',
              NOW()
            )");
          }
          //decoding JSON
          $arrayData = json_decode(stripslashes($tasks), true);
          foreach($arrayData as $data){
            $thisTaskID = $data['taskId'];
            $thisTaskName = $data['taskName'];
            $thisTaskStatus = $data['taskStatus'];
            $conn->query("UPDATE tb_task_list SET taskStatus = '".$thisTaskStatus."' WHERE scheduleId = '".$scheduleId."' AND taskId = '".$thisTaskID."' ");
          }
          $status = "success";
          $daJson["activityId"] = $activityId;
          $daJson["status"] = $status;
          $printJson = json_encode($daJson);
          echo $printJson;
          exit();
        }
      }

    }
  }

} else {
  $pesan = "Error! no action detected!";
}

$daJson["pesan"] = $pesan;
$daJson["status"] = $status;
$printJson = json_encode($daJson);
echo $printJson;
exit();
?>

<?php
include '../../config.php';
$output;

//Checked
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    parse_str(file_get_contents("php://input"), $_DELETE);
    $personId = $_DELETE['id'];
    $userHash = $_DELETE['hash'];

    if (
        isset($personId) && !empty($personId) && $personId != 'undefined' &&
        isset($userHash) && !empty($userHash) && $userHash != 'undefined'
    ) {
        $sql = $conn->prepare(
            "SELECT userName 
            FROM tb_users 
            WHERE hashWeb = ?"
        );
        $sql->bind_param('s', $userHash);
        $sql->execute();
        $userResult = $sql->get_result();
        if ($userResult->num_rows > 0) {
            while ($rowUser = $userResult->fetch_assoc()) {

                $sql = $conn->prepare(
                    "SELECT personName 
                    FROM tb_person 
                    WHERE personId = ?"
                );
                $sql->bind_param('s', $personId);
                $sql->execute();
                $result = $sql->get_result();
                if ($result->num_rows > 0) {
                    while ($rowPerson = $result->fetch_assoc()) {
                        
                        try {
                            $conn->begin_transaction();

                            $newName = $rowPerson['personName'] . ' DELETED';
                            $sql = $conn->prepare(
                                "UPDATE tb_person 
                                SET isDeleted = '1', personName = ?, userName = ? 
                                WHERE personId = ?"
                            );
                            $sql->bind_param('sss', $newName, $rowUser['userName'], $personId);
                            if ($sql->execute() === FALSE) {
                                $output->status = 'failed';
                                $output->action = 'update';
                                echo (json_encode($output));
                                throw new Exception('Statement UPDATE Failed');
                            }
                        } catch (Exception $e) {
                            $conn->rollback();
                        } finally {
                            $output->status = 'success';
                            echo (json_encode($output));
                            $conn->commit();
                        }
                    }
                } else {
                    $output->status = 'false';
                    echo (json_encode($output));
                }
            }
        } else {
            $output->status = 'false';
            echo (json_encode($output));
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

//Checked
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    parse_str(file_get_contents("php://input"), $_PUT);
    $personName = $_PUT['person'];
    $personId = $_PUT['id'];
    $userHash = $_PUT['hash'];

    if (
        isset($personName) && !empty($personName) && $personName != 'undefined' &&
        isset($personId) && !empty($personId) && $personId != 'undefined' &&
        isset($userHash) && !empty($userHash) && $userHash != 'undefined'
    ) {
        $sql = $conn->prepare(
            "SELECT userName 
            FROM tb_users 
            WHERE hashWeb = ?"
        );
        $sql->bind_param('s', $userHash);
        $sql->execute();
        $userResult = $sql->get_result();
        if ($userResult->num_rows > 0) {
            while ($rowUser = $userResult->fetch_assoc()) {

                try {
                    $conn->begin_transaction();

                    $sql = $conn->prepare(
                        "UPDATE tb_person 
                        SET personName = ?, userName = ? 
                        WHERE personId = ?"
                    );
                    $sql->bind_param('sss', $personName, $rowUser['userName'], $personId);
                    if ($sql->execute() === FALSE) {
                        $output->status = 'failed';
                        $output->action = 'update';
                        echo (json_encode($output));
                        throw new Exception('Statement UPDATE Failed');
                    }
                } catch (Exception $e) {
                    $conn->rollback();
                } finally {
                    $output->status = 'success';
                    echo (json_encode($output));
                    $conn->commit();
                }
            }
        } else {
            $output->status = 'false';
            echo (json_encode($output));
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

//Checked
if ($_SERVER['REQUEST_METHOD'] === 'PATCH') {
    parse_str(file_get_contents("php://input"), $_PATCH);
    $mappingTag = $_PATCH['id'];

    if (isset($mappingTag) && !empty($mappingTag) && $mappingTag != 'undefined') {
        $sql = $conn->prepare(
            "SELECT DISTINCT phaseId 
            FROM tb_schedule, tb_activity
            WHERE tb_activity.activityId = tb_schedule.activityId 
            AND scheduleDate = CURRENT_DATE
            AND scheduleStart <= CURRENT_TIME
            AND activityStatus = '0'
            ORDER BY tb_schedule.uid ASC LIMIT 1"
        );
        $sql->execute();
        $getPhase = $sql->get_result();
        if ($getPhase->num_rows > 0) {
            while ($rowPhase = $getPhase->fetch_assoc()) {
                $sql = $conn->prepare(
                    "SELECT personName, mappingName 
                    FROM tb_person, tb_person_mapping, tb_schedule, tb_activity
                    WHERE tb_schedule.mappingId = tb_person_mapping.mappingId 
                    AND tb_schedule.personId = tb_person.personId 
                    AND tb_schedule.scheduleId = tb_activity.scheduleId 
                    AND mappingTag = ? 
                    AND activityStatus = '0' 
                    AND phaseId = ?
                    ORDER BY scheduleDate ASC, scheduleStart ASC LIMIT 1"
                );
                $sql->bind_param('ss', $mappingTag, $rowPhase['phaseId']);
                $sql->execute();
                $result = $sql->get_result();
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        $output->status = 'success';
                        $output->person = ucfirst($row['personName']);
                        $output->mapping = ucfirst($row['mappingName']);
                        echo (json_encode($output));
                    }
                } else {
                    $sql = $conn->prepare(
                        "SELECT mappingName 
                        FROM tb_person_mapping 
                        WHERE mappingTag = ?"
                    );
                    $sql->bind_param('s', $mappingTag);
                    $sql->execute();
                    $mapping = $sql->get_result();
                    if ($mapping->num_rows > 0) {
                        while ($row = $mapping->fetch_assoc()) {
                            $output->status = 'success';
                            $output->person = 'unknown';
                            $output->mapping = ucfirst($row['mappingName']);
                            echo (json_encode($output));
                        }
                    } else {
                        $output->status = 'false';
                        echo (json_encode($output));
                    }
                }
            }
        } else {
            $output->status = 'false';
            echo (json_encode($output));
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

//Checked
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $personName = strtolower($_POST['name']);
    $userHash = $_POST['hash'];
    $postDevice = $_GET['device'];

    switch ($postDevice) {
        case 'web':
            if (
                isset($personName) && !empty($personName) && $personName != 'undefined' &&
                isset($userHash) && !empty($userHash) && $userHash != 'undefined'
            ) {
                $sql = $conn->prepare(
                    "SELECT userName
                    FROM tb_users 
                    WHERE hashWeb = ?"
                );
                $sql->bind_param('s', $userHash);
                $sql->execute();
                $userResult = $sql->get_result();
                if ($userResult->num_rows > 0) {
                    while ($rowUser = $userResult->fetch_assoc()) {

                        $sql = $conn->prepare(
                            "SELECT personName 
                            FROM tb_person 
                            WHERE personName = ?"
                        );
                        $sql->bind_param('s', $personName);
                        $sql->execute();
                        $nameResult = $sql->get_result();
                        if ($nameResult->num_rows > 0) {
                            $output->status = 'exist';
                            echo (json_encode($output));
                        } else {
                            $sql = $conn->prepare(
                                "SELECT personId 
                                FROM tb_person 
                                ORDER BY uid DESC LIMIT 1"
                            );
                            $sql->execute();
                            $personResult = $sql->get_result();
                            $personId = '1';
                            while ($row = $personResult->fetch_assoc()) {
                                $personId = (int)$row['personId'] + 1;
                            }

                            try {
                                $conn->begin_transaction();

                                $sql = $conn->prepare(
                                    "INSERT INTO tb_person (personId, personName, isDeleted, userName) 
                                    VALUES (?, ?, '0', ?)"
                                );
                                $sql->bind_param('iss', $personId, $personName, $rowUser['userName']);
                                if ($sql->execute() === FALSE) {
                                    $output->status = 'failed';
                                    $output->action = 'insert';
                                    echo (json_encode($output));
                                    throw new Exception('Statement INSERT Failed');
                                }
                            } catch (Exception $e) {
                                $conn->rollback();
                            } finally {
                                $output->status = 'success';
                                echo (json_encode($output));
                                $conn->commit();
                            }
                        }
                    }
                } else {
                    $output->status = 'false';
                    echo (json_encode($output));
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
        case 'mobile':
            $mappingTag = $_POST['id'];

            if (
                isset($personName) && !empty($personName) && $personName != 'undefined' &&
                isset($userHash) && !empty($userHash) && $userHash != 'undefined' &&
                isset($mappingTag) && !empty($mappingTag) && $mappingTag != 'undefined'
            ) {
                $sql = $conn->prepare(
                    "SELECT userName 
                    FROM tb_users 
                    WHERE hashMobile = ?"
                );
                $sql->bind_param('s', $userHash);
                $sql->execute();
                $userResult = $sql->get_result();
                if ($userResult->num_rows > 0) {
                    while ($rowUser = $userResult->fetch_assoc()) {

                        $sql = $conn->prepare(
                            "SELECT mappingId 
                            FROM tb_person_mapping 
                            WHERE mappingTag = ?"
                        );
                        $sql->bind_param('s', $mappingTag);
                        $sql->execute();
                        $tag = $sql->get_result();
                        if ($tag->num_rows > 0) {
                            $output->status = 'exist';
                            echo (json_encode($output));
                        } else {
                            $sql = $conn->prepare(
                                "SELECT mappingId 
                                FROM tb_person_mapping 
                                ORDER BY uid DESC LIMIT 1"
                            );
                            $sql->execute();
                            $result = $sql->get_result();
                            $mappingId = '1';
                            while ($row = $result->fetch_assoc()) {
                                $mappingId = $row['mappingId'] + 1;
                            }

                            try {
                                $conn->begin_transaction();

                                $sql = $conn->prepare(
                                    "INSERT into tb_person_mapping (mappingId, mappingTag, mappingName, username) 
                                    VALUES (?, ?, ?, ?)"
                                );
                                $sql->bind_param('ssss', $mappingId, $mappingTag, $personName, $rowUser['userName']);
                                if ($sql->execute() === FALSE) {
                                    $output->status = 'failed';
                                    $output->action = 'insert';
                                    echo (json_encode($output));
                                    throw new Exception('Statement INSERT Failed');
                                }
                            } catch (Exception $e) {
                                $conn->rollback();
                            } finally {
                                $output->status = 'success';
                                echo (json_encode($output));
                                $conn->commit();
                            }
                        }
                    }
                } else {
                    $output->status = 'false';
                    echo (json_encode($output));
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
    }
}

//Checked
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $userHash = $_GET['hash'];
    $postDevice = $_GET['device'];
    $action = $_GET['action'];

    switch ($action) {
        case 'person':
            if (
                isset($userHash) && !empty($userHash) && $userHash != 'undefined' &&
                isset($postDevice) && !empty($postDevice) && $postDevice != 'undefined'
            ) {
                switch ($postDevice) {
                    case 'web':
                        $sql = $conn->prepare(
                            "SELECT userId 
                            FROM tb_users 
                            WHERE hashWeb = ?"
                        );
                        $sql->bind_param('s', $userHash);
                        $sql->execute();
                        break;
                    case 'mobile':
                        $sql = $conn->prepare(
                            "SELECT userId 
                            FROM tb_users 
                            WHERE hashMobile = ?"
                        );
                        $sql->bind_param('s', $userHash);
                        $sql->execute();
                        break;
                }
                
                $resultCheck = $sql->get_result();
                if ($resultCheck->num_rows > 0) {
                    $sql = $conn->prepare(
                        "SELECT personName, personId, lastUpdated 
                        FROM tb_person 
                        WHERE isDeleted = '0'"
                    );
                    $sql->execute();
                    $result = $sql->get_result();
                    if ($result->num_rows > 0) {
                        $personArray = [];
                        while ($row = $result->fetch_assoc()) {
                            $personArray[] = (object) [
                                'ref' => $row['personId'],
                                'name' => ucfirst($row['personName']),
                                'update' => date('d/m/Y (H:i)', strtotime($row['lastUpdated'])),
                            ];
                        }
                        $output->status = 'success';
                        $output->person = $personArray;
                        echo (json_encode($output));
                    } else {
                        $output->status = 'false';
                        echo (json_encode($output));
                    }
                } else {
                    $output->status = 'unauth';
                    echo (json_encode($output));
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
        case 'mapping':
            if (isset($userHash) && !empty($userHash) && $userHash != 'undefined') {
                $sql = $conn->prepare(
                    "SELECT userId 
                    FROM tb_users 
                    WHERE hashWeb = ?"
                );
                $sql->bind_param('s', $userHash);
                $sql->execute();
                $userResult = $sql->get_result();
                if ($userResult->num_rows > 0) {
                    $sql = $conn->prepare(
                        "SELECT mappingId, mappingName, lastUpdated 
                        FROM tb_person_mapping"
                    );
                    $sql->execute();
                    $result = $sql->get_result();
                    if ($result->num_rows > 0) {
                        $mappingArray = [];
                        while ($row = $result->fetch_assoc()) {

                            $mappingArray[] = (object) [
                                'id' => $row['mappingId'],
                                'name' => ucfirst($row['mappingName']),
                                'update' => date('d/m/Y (H:i)', strtotime($row['lastUpdated'])),
                            ];
                        }
                        $output->status = 'success';
                        $output->mapping = $mappingArray;
                        echo (json_encode($output));
                    } else {
                        $output->status = 'false';
                        echo (json_encode($output));
                    }
                } else {
                    $output->status = 'unauth';
                    echo (json_encode($output));
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
        case 'list':
            if (isset($postDevice) && !empty($postDevice) && $postDevice != 'undefined') {
                $sql = $conn->prepare(
                    "SELECT mappingTag, mappingName, lastUpdated 
                    FROM tb_person_mapping"
                );
                $sql->execute();
                $result = $sql->get_result();
                if ($result->num_rows > 0) {
                    $mappingArray = [];
                    while ($row = $result->fetch_assoc()) {

                        $sql = $conn->prepare(
                            "SELECT personName, mappingName 
                            FROM tb_person, tb_person_mapping, tb_schedule, tb_activity
                            WHERE tb_schedule.mappingId = tb_person_mapping.mappingId 
                            AND tb_schedule.personId = tb_person.personId 
                            AND tb_schedule.scheduleId = tb_activity.scheduleId 
                            AND mappingTag = ? 
                            AND activityStatus = '0' 
                            AND scheduleDate >= CURDATE() 
                            AND scheduleStart >= CURRENT_TIME
                            ORDER BY scheduleDate ASC, scheduleStart ASC LIMIT 1"
                        );
                        $sql->bind_param('s', $row['mappingTag']);
                        $sql->execute();
                        $bindResult = $sql->get_result();
                        if ($bindResult->num_rows > 0) {
                            while ($rowBind = $bindResult->fetch_assoc()) {

                                $mappingArray[] = (object) [
                                    'id' => $row['mappingTag'],
                                    'tag' => ucfirst($row['mappingName']),
                                    'name' => ucfirst($rowBind['personName']),
                                ];

                            }
                        } else {
                            $mappingArray[] = (object) [
                                'id' => $row['mappingTag'],
                                'tag' => ucfirst($row['mappingName']),
                                'name' => 'Not Set',
                            ];
                        }
                    }
                    $output->status = 'success';
                    $output->mapping = $mappingArray;
                    echo (json_encode($output));
                } else {
                    $output->status = 'false';
                    echo (json_encode($output));
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
    }
}

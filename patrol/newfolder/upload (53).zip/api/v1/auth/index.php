<?php
include '../../config.php';
include '../../hash.php';
$output;

// $authorization = explode(" ", getallheaders()['Authorization']);
// $hash = $authorization[1];
// $sql = $conn->prepare("SELECT uid FROM tb_users WHERE hashWeb = ?");
// $sql->bind_param('s', $hash);
// $sql->execute();
// $result = $sql->get_result();
// if ($result->num_rows > 0) {
    
// } else {
//     header('HTTP/1.1 401 Unauthorized');
//     exit;
// }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postName = $_POST['username'];
    $postPassword = $_POST['password'];
    $device = $_POST['device'];
    $action = $_GET['action'];

    switch ($action) {
        case 'token':
            $hash = $_POST['hash'];

            if (isset($hash) && !empty($hash) && $hash != 'undefined') {
                $sql = $conn->prepare("SELECT uid FROM tb_users WHERE hashWeb = ?");
                $sql->bind_param('s', $hash);
                $sql->execute();
                $result = $sql->get_result();
                if ($result->num_rows > 0) {
                    $sql = $conn->prepare("SELECT COUNT(uid) as tokenSum FROM tb_token");
                    $sql->execute();
                    $result = $sql->get_result();
                    $tokenSum = '0';
                    while ($row = $result->fetch_assoc()) {
                        $tokenSum = $row['tokenSum'];
                    }
                    if ($tokenSum > 5) {
                        $sql = $conn->prepare("SELECT uid FROM tb_token ORDER BY uid ASC LIMIT 1");
                        $sql->execute();
                        $result = $sql->get_result();
                        while ($row = $result->fetch_assoc()) {
                            $sql = $conn->prepare("DELETE FROM tb_token WHERE uid = ?");
                            $sql->bind_param('s', $row['uid']);
                            $sql->execute();
                        }
                    }
                    $token = generateHash();
                    $sql = $conn->prepare("INSERT INTO tb_token (token, status) VALUES (?, '0')");
                    $sql->bind_param('s', $token);
                    if ($sql->execute() === TRUE) {
                        $output->status = 'success';
                        $output->token = $token;
                        echo (json_encode($output));
                    }
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
        default:
            if (
                isset($postName) && !empty($postName) && $postName != 'undefined' &&
                isset($postPassword) && !empty($postPassword) && $postPassword != 'undefined' &&
                isset($device) && !empty($device) && $device != 'undefined'
            ) {
                $username = strtolower($postName) ?? '';
                $password = hash('sha256', $postPassword);
                $sql = $conn->prepare(
                    "SELECT userName, userPassword, userLevel
                    FROM tb_users
                    WHERE userName = ?
                    AND userPassword = ?"
                );
                $sql->bind_param("ss", $postName, $password);
                $sql->execute();
                $result = $sql->get_result();
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        if ($row["userLevel"] > 0) {
                            if ($password == $row["userPassword"] && $username == $row["userName"]) {
                                $hash = generateHash();
                                switch ($device) {
                                    case 'web':
                                        $sql = $conn->prepare(
                                            "UPDATE tb_users
                                            SET hashWeb = ?
                                            WHERE userName = ?"
                                        );
                                        $sql->bind_param("ss", $hash, $username);
                                        break;
                                    case 'mobile':
                                        $sql = $conn->prepare(
                                            "UPDATE tb_users
                                            SET hashMobile = ?
                                            WHERE userName = ?"
                                        );
                                        $sql->bind_param("ss", $hash, $username);
                                        break;
                                }
                                try {
                                    $conn->begin_transaction();

                                    if ($sql->execute() === FALSE) {
                                        $output->status = 'failed';
                                        $output->action = 'update';
                                        echo (json_encode($output));
                                        throw new Exception('Statement UPDATE Failed');
                                    }
                                } catch (Exception $e) {
                                    $conn->rollback();
                                } finally {
                                    $conn->commit();
                                    if (!empty($action)) {
                                        switch ($device) {
                                            case 'web':
                                                $output->status = 'success';
                                                $output->level = $row['userLevel'];
                                                $output->hash = $hash;
                                                echo (json_encode($output));
                                                break;
                                            case 'mobile':
                                                $output->status = 'success';
                                                $output->hash = $hash;
                                                echo (json_encode($output));
                                                break;
                                        }
                                    } else {
                                        $output->status = 'false';
                                        echo (json_encode($output));
                                    }
                                }
                            } else {
                                $output->status = 'false';
                                echo (json_encode($output));
                            }
                        } else {
                            $output->status = 'unauth';
                            echo (json_encode($output));
                        }
                    }
                } else {
                    $output->status = 'false';
                    echo (json_encode($output));
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
    }
    
}

//Checked
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $hash = $_GET['hash'];
    $device = $_GET['device'];

    if (
        isset($hash) && !empty($hash) && $hash != 'undefined' &&
        isset($device) && !empty($device) && $device != 'undefined'
    ) {
        switch ($device) {
            case 'web':
                $sql = $conn->prepare(
                    "SELECT username, userLevel
                    FROM tb_users
                    WHERE hashWeb = ?"
                );
                $sql->bind_param("s", $hash);
                $sql->execute();
                break;
            case 'mobile':
                $sql = $conn->prepare(
                    "SELECT username
                    FROM tb_users
                    WHERE hashMobile = ?"
                );
                $sql->bind_param("s", $hash);
                $sql->execute();
                break;
        }
        
        $result = $sql->get_result();
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                switch ($device) {
                    case 'web':
                        $output->status = 'success';
                        $output->level = $row['userLevel'];
                        echo (json_encode($output));
                        break;
                    case 'mobile':
                        $output->status = 'success';
                        echo (json_encode($output));
                        break;
                }
            }
        } else {
            $output->status = 'false';
            echo (json_encode($output));
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}
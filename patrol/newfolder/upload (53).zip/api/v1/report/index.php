<?php
include '../../config.php';
$output;

//Checked
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $postHash = $_GET['hash'];
    $filter = $_GET['filter'].'%';
    $action = $_GET['action'];

    switch ($action) {
        case 'date':
            if (isset($postHash) && !empty($postHash) && $postHash != 'undefined') {
                $sql = $conn->prepare(
                    "SELECT userId
                    FROM tb_users
                    WHERE hashWeb = ?"
                );
                $sql->bind_param('s', $postHash);
                $sql->execute();
                $resultCheck = $sql->get_result();
                if ($resultCheck->num_rows > 0) {
                    if ($filter == '%') {
                        $sql = $conn->prepare(
                            "SELECT DISTINCT reportDate
                            FROM tb_report
                            WHERE reportDate LIKE ?
                            ORDER BY reportDate DESC LIMIT 30"
                        );
                    } else {
                        $sql = $conn->prepare(
                            "SELECT DISTINCT reportDate 
                            FROM tb_report 
                            WHERE reportDate LIKE ? 
                            ORDER BY reportDate DESC"
                        );
                    }
                    $sql->bind_param('s', $filter);
                    $sql->execute();
                    $result = $sql->get_result();
                    if ($result->num_rows > 0) {
                        $reportDate = [];
                        while ($row = $result->fetch_assoc()) {
                            $sql = $conn->prepare(
                                "SELECT COUNT(DISTINCT tb_schedule.phaseId) as phase 
                                FROM tb_phase, tb_schedule, tb_activity 
                                WHERE tb_schedule.phaseId = tb_phase.phaseId 
                                AND tb_activity.activityId = tb_schedule.activityId 
                                AND phaseDate = ? 
                                AND activityStatus = '1'"
                            );
                            $sql->bind_param('s', $row['reportDate']);
                            $sql->execute();
                            $subResult = $sql->get_result();
                            $phaseCount;
                            while ($subRow = $subResult->fetch_assoc()) {
                                $phaseCount = $subRow['phase'];
                            }

                            $sql = $conn->prepare(
                                "SELECT DISTINCT tb_schedule.phaseId 
                                FROM tb_phase, tb_schedule, tb_activity 
                                WHERE tb_schedule.phaseId = tb_phase.phaseId 
                                AND tb_activity.activityId = tb_schedule.activityId 
                                AND phaseDate = ? 
                                AND activityStatus = '1'"
                            );
                            $sql->bind_param('s', $row['reportDate']);
                            $sql->execute();
                            $subResult = $sql->get_result();
                            $phase = [];
                            while ($subRow = $subResult->fetch_assoc()) {
                                $sql = $conn->prepare(
                                    "SELECT
                                    SUBSTRING_INDEX(GROUP_CONCAT(scheduleStart ORDER BY scheduleStart ASC), ',', 1) AS start,
                                    SUBSTRING_INDEX(GROUP_CONCAT(scheduleStart ORDER BY scheduleStart DESC), ',', 1) AS finish
                                    FROM tb_schedule
                                    WHERE phaseId = ?"
                                );
                                $sql->bind_param('s', $subRow['phaseId']);
                                $sql->execute();
                                $getTime = $sql->get_result();
                                while ($timeRow = $getTime->fetch_assoc()) {
                                    $phase[] = (object) [
                                        'id' => $subRow['phaseId'],
                                        'schedule' => substr($timeRow['start'], 0, 5).' - '.substr($timeRow['finish'], 0, 5)
                                    ];
                                }
                            }

                            $date = date_create(substr($row['reportDate'], 0, 10));
                            $reportDate[] = (object) [
                                'id' => $row['reportDate'],
                                'date' => date_format($date, 'd F Y'),
                                'phase' => $phase,
                                'count' => $phaseCount
                            ];
                        }
                        $output->status = 'success';
                        $output->data = $reportDate;
                        echo (json_encode($output));
                    } else {
                        $output->status = 'false';
                        echo (json_encode($output));
                    }
                } else {
                    $output->status = 'false';
                    echo (json_encode($output));
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
        default:
            if (isset($postHash) && !empty($postHash) && $postHash != 'undefined') {
                $sql = $conn->prepare(
                    "SELECT userId
                    FROM tb_users
                    WHERE hashWeb = ?"
                );
                $sql->bind_param('s', $postHash);
                $sql->execute();
                $resultCheck = $sql->get_result();
                if ($resultCheck->num_rows > 0) {
                    $sql = $conn->prepare(
                        "SELECT DISTINCT activityId
                        FROM tb_report"
                    );
                    $sql->execute();
                    $activityResult = $sql->get_result();
                    if ($activityResult->num_rows > 0) {
                        $personArray = [];
                        $i = 1;
                        while ($activityRow = $activityResult->fetch_assoc()) {

                            $sql = $conn->prepare(
                                "SELECT scheduleId, personName, tb_report.activityId,
                                GROUP_CONCAT(checkpointName separator ' to ') as checkpointName, GROUP_CONCAT(reportLatitude) as latitude,
                                GROUP_CONCAT(reportLongitude) as longitude, activityStart, activityEnd, reportNote
                                FROM tb_activity, tb_report, tb_person
                                WHERE tb_person.personId = tb_report.personId
                                AND tb_report.activityId = tb_activity.activityId
                                AND tb_report.activityId = ?
                                AND tb_activity.activityStatus = '1'"
                            );
                            $sql->bind_param('s', $activityRow['activityId']);
                            $sql->execute();
                            $result = $sql->get_result();
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {

                                    $sql = $conn->prepare(
                                        "SELECT taskName, taskStatus
                                        FROM tb_task_list, tb_task
                                        WHERE tb_task_list.taskId = tb_task.taskId
                                        AND scheduleId = ?"
                                    );
                                    $sql->bind_param('s', $row['scheduleId']);
                                    $sql->execute();
                                    $task = $sql->get_result();
                                    if ($task->num_rows > 0) {
                                        $taskArray = [];
                                        while ($rowTask = $task->fetch_assoc()) {

                                            $taskArray[] = (object) [
                                                'name' => ucfirst($rowTask['taskName']),
                                                'status' => $rowTask['taskStatus'],
                                            ];
                                        }
                                        $latitude = explode(',', $row['latitude']);
                                        $longitude = explode(',', $row['longitude']);
                                        if ($row['personName']) {
                                            $date = date_create(substr($row['activityStart'], 0, 10));
                                            $personArray[] = (object) [
                                                'no' => $i,
                                                'person' => ucfirst($row['personName']),
                                                'checkpoint' => $row['checkpointName'],
                                                'startLocation' => $longitude[0] . ',' . $latitude[0],
                                                'endLocation' => $longitude[1] . ',' . $latitude[1],
                                                'task' => $taskArray,
                                                'note' => $row['reportNote'],
                                                'date' => date_format($date, 'd/m/Y'),
                                                'time' => substr($row['activityStart'], 11) . ' WIB - ' . substr($row['activityEnd'], 11) . ' WIB'
                                            ];
                                        }
                                    } else {
                                        $latitude = explode(',', $row['latitude']);
                                        $longitude = explode(',', $row['longitude']);
                                        if ($row['personName']) {
                                            $date = date_create(substr($row['activityStart'], 0, 10));
                                            $personArray[] = (object) [
                                                'no' => $i,
                                                'person' => ucfirst($row['personName']),
                                                'checkpoint' => $row['checkpointName'],
                                                'startLocation' => $longitude[0] . ',' . $latitude[0],
                                                'endLocation' => $longitude[1] . ',' . $latitude[1],
                                                'task' => null,
                                                'note' => $row['reportNote'],
                                                'date' => date_format($date, 'd/m/Y'),
                                                'time' => substr($row['activityStart'], 11) . ' WIB - ' . substr($row['activityEnd'], 11) . ' WIB'
                                            ];
                                        }
                                    }
                                }
                            }
                            $i++;
                        }
                        $output->status = 'success';
                        $output->person = $personArray;
                        echo (json_encode($output));
                    } else {
                        $output->status = 'false';
                        echo (json_encode($output));
                    }
                } else {
                    $output->status = 'false';
                    echo (json_encode($output));
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
    }
}

//Checked
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $personId = $_POST['person'];
    $activityId = $_POST['activity'];
    $scheduleId = $_POST['schedule'];
    $checkpointId = $_POST['checkpoint'];
    $reportLatitude = $_POST['latitude'];
    $reportLongitude = $_POST['longitude'];
    $reportTime = date('H:i:s');
    $reportDate = date('Y-m-d');

    if (
        isset($personId) && !empty($personId) && $personId != 'undefined' &&
        isset($checkpointId) && !empty($checkpointId) && $checkpointId != 'undefined' &&
        isset($reportLatitude) && !empty($reportLatitude) && $reportLatitude != 'undefined' &&
        isset($reportLongitude) && !empty($reportLongitude) && $reportLongitude != 'undefined' &&
        isset($activityId) && !empty($activityId) && $activityId != 'undefined' &&
        isset($scheduleId) && !empty($scheduleId) && $scheduleId != 'undefined'
    ) {
        $sql = $conn->prepare(
            "SELECT checkpointName
            FROM tb_checkpoint
            WHERE checkpointId = ?"
        );
        $sql->bind_param('s', $checkpointId);
        $sql->execute();
        $checkpointResult = $sql->get_result();
        if ($checkpointResult->num_rows > 0) {
            $checkpointName;
            while ($row = $checkpointResult->fetch_assoc()) {
                $checkpointName = $row['checkpointName'];
            }
            $sql = $conn->prepare(
                "SELECT reportId
                FROM tb_report
                WHERE activityId = ?
                AND checkpointName = ?"
            );
            $sql->bind_param('ss', $activityId, $checkpointName);
            $sql->execute();
            $isExist = $sql->get_result();
            if ($isExist->num_rows > 0) {
                $output->status = 'success';
                echo (json_encode($output));
            } else {
                $sql = $conn->prepare(
                    "SELECT reportId
                    FROM tb_report
                    ORDER BY uid DESC LIMIT 1"
                );
                $sql->execute();
                $sqlResult = $sql->get_result();
                $reportId = '1';
                while ($rowCheck = $sqlResult->fetch_assoc()) {
                    $reportId = (int)$rowCheck['reportId'] + 1;
                }

                try {
                    $conn->begin_transaction();

                    $sql = $conn->prepare(
                        "INSERT INTO tb_report (reportId, reportLatitude, reportLongitude, activityId, personId, checkpointName, reportDate, reportTime)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
                    );
                    $sql->bind_param('isssssss', $reportId, $reportLatitude, $reportLongitude, $activityId, $personId, $checkpointName, $reportDate, $reportTime);
                    if ($sql->execute() === FALSE) {
                        $output->status = 'failed';
                        $output->action = 'insert';
                        $output->table = 'report';
                        echo (json_encode($output));
                        throw new Exception('Statement INSERT Failed');
                    }
                } catch (Exception $e) {
                    $conn->rollback();
                } finally {
                    $output->status = 'success';
                    echo (json_encode($output));
                    $conn->commit();
                }
            }
        } else {
            $output->status = 'false';
            echo (json_encode($output));
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

<?php
include '../../config.php';
$output;

//REMOVE CHECKPOINT
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    parse_str(file_get_contents("php://input"), $_DELETE);
    $checkpointId = $_DELETE['id'];
    $userHash = $_DELETE['hash'];

    if (
        isset($checkpointId) && !empty($checkpointId) && $checkpointId != 'undefined' &&
        isset($userHash) && !empty($userHash) && $userHash != 'undefined'
    ) {
        $sql = $conn->prepare(
            "SELECT userName
            FROM tb_users
            WHERE hashWeb = ?"
        );
        $sql->bind_param('s', $userHash);
        $sql->execute();
        $result = $sql->get_result();
        if ($result->num_rows > 0) {
            try {
                $conn->begin_transaction();

                $sql = $conn->prepare(
                    "UPDATE tb_checkpoint
                    SET isDeleted = '1'
                    WHERE checkpointId = ?"
                );
                $sql->bind_param('s', $checkpointId);
                if ($sql->execute() === FALSE) throw new Exception('Statement UPDATE Failed');

            } catch (Exception $e) {
                $output->status = 'failed';
                echo (json_encode($output));
                $conn->rollback();
                exit();
            } finally {
                $output->status = 'success';
                echo (json_encode($output));
                $conn->commit();
            }
        } else {
            $output->status = 'error';
            $output->message = 'No authentication';
            echo (json_encode($output));
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    parse_str(file_get_contents("php://input"), $_PUT);
    $checkpointId = $_PUT['id'];
    $userHash = $_PUT['hash'];
    $action = $_GET['action'];

    if (isset($userHash) && !empty($userHash) && $userHash != 'undefined') {
        $sql = $conn->prepare(
            "SELECT userName
            FROM tb_users
            WHERE hashWeb = ?"
        );
        $sql->bind_param('s', $userHash);
        $sql->execute();
        $result = $sql->get_result();
        $userName;
        while ($row = $result->fetch_assoc()) {
            $userName = $row['userName'];
        }

        switch ($action) {
            //EDIT CHECKPOINT NAME
            case 'edit':
                $checkpointName = $_PUT['checkpoint'];
    
                if (
                    isset($checkpointName) && !empty($checkpointName) && $checkpointName != 'undefined' &&
                    isset($checkpointId) && !empty($checkpointId) && $checkpointId != 'undefined'
                ) {
                    try {
                        $conn->begin_transaction();
    
                        $sql = $conn->prepare(
                            "UPDATE tb_checkpoint
                                SET checkpointName = ?, userName = ?
                                WHERE checkpointId = ?"
                        );
                        $sql->bind_param('sss', $checkpointName, $userName, $checkpointId);
                        if ($sql->execute() === FALSE) throw new Exception('Statement UPDATE Failed');
                    } catch (Exception $e) {
                        $output->status = 'failed';
                        echo (json_encode($output));
                        $conn->rollback();
                        exit();
                    } finally {
                        $output->status = 'success';
                        echo (json_encode($output));
                        $conn->commit();
                    }
                } else {
                    $output->status = 'error';
                    echo (json_encode($output));
                }
                break;
            //SET CHECKPOINT LOCATION
            case 'set':
                $latitude = $_PUT['latitude'];
                $longitude = $_PUT['longitude'];
    
                if (
                    isset($checkpointId) && !empty($checkpointId) && $checkpointId != 'undefined' &&
                    isset($latitude) && !empty($latitude) && $latitude != 'undefined' &&
                    isset($longitude) && !empty($longitude) && $longitude != 'undefined'
                ) {
                    try {
                        $conn->begin_transaction();
        
                        $sql = $conn->prepare(
                            "UPDATE tb_checkpoint
                            SET checkLatitude = ?, checkLongitude = ?, userName = ?
                            WHERE checkpointId =?"
                        );
                        $sql->bind_param('ssss', $latitude, $longitude, $userName, $checkpointId);
                        if ($sql->execute() === FALSE) throw new Exception('Statement UPDATE Failed');
    
                    } catch (Exception $e) {
                        $output->status = 'failed';
                        echo (json_encode($output));
                        $conn->rollback();
                        exit();
                    } finally {
                        $output->status = 'success';
                        echo (json_encode($output));
                        $conn->commit();
                    }
                } else {
                    $output->status = 'error';
                    echo (json_encode($output));
                }
                break;
            //TOGGLE ENABLE/DISABLE CHECKPOINT
            case 'toggle':
                if (isset($checkpointId) && !empty($checkpointId) && $checkpointId != 'undefined') {
                    $sql = $conn->prepare(
                        "SELECT checkStatus
                        FROM tb_checkpoint
                        WHERE checkpointId = ?"
                    );
                    $sql->bind_param('s', $checkpointId);
                    $sql->execute();
                    $result = $sql->get_result();
                    $checkStatus;
                    while ($row = $result->fetch_assoc()) {
                        $checkStatus = $row['checkStatus'];
                    }
    
                    try {
                        $conn->begin_transaction();
    
                        switch ($checkStatus) {
                            case '0':
                                $sql = $conn->prepare(
                                    "UPDATE tb_checkpoint
                                    SET checkStatus = '1', userName = ?
                                    WHERE checkpointId = ?"
                                );
                                $sql->bind_param('ss', $userName, $checkpointId);
                                if ($sql->execute() === FALSE) throw new Exception('Statement UPDATE Failed');
                                break;
                            case '1':
                                $sql = $conn->prepare(
                                    "UPDATE tb_checkpoint
                                    SET checkStatus = '0', userName = ?
                                    WHERE checkpointId = ?"
                                );
                                $sql->bind_param('ss', $userName, $checkpointId);
                                if ($sql->execute() === FALSE) throw new Exception('Statement UPDATE Failed');
                                break;
                        }
                    } catch (Exception $e) {
                        $output->status = 'failed';
                        echo (json_encode($output));
                        $conn->rollback();
                        exit();
                    } finally {
                        $output->status = 'success';
                        echo (json_encode($output));
                        $conn->commit();
                    }
                } else {
                    $output->status = 'error';
                    echo (json_encode($output));
                }
                break;
            default:
                $output->status = 'error';
                echo (json_encode($output));
                break;
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

//ADD CHECKPOINT
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $checkpointId = $_POST['id'];
    $checkpointName = strtoupper($_POST['name']);
    $checkLatitude = '-';
    $checkLongitude = '-';
    $userHash = $_POST['hash'];

    if (
        isset($userHash) && !empty($userHash) && $userHash != 'undefined' &&
        isset($checkpointName) && !empty($checkpointName) && $checkpointName != 'undefined'
    ) {
        $sql = $conn->prepare(
            "SELECT userName
            FROM tb_users
            WHERE hashMobile = ?"
        );
        $sql->bind_param('s', $userHash);
        $sql->execute();
        $result = $sql->get_result();
        $userName;
        while ($row = $result->fetch_assoc()) {
            $userName = $row['userName'];
        }

        $sql = $conn->prepare(
            "SELECT checkpointName
            FROM tb_checkpoint
            WHERE checkpointName = ?"
        );
        $sql->bind_param('s', $checkpointName);
        $sql->execute();
        $result = $sql->get_result();
        if ($result->num_rows > 0) {
            $output->status = 'exist';
            echo (json_encode($output));
        } else {
            $sql = $conn->prepare(
                "SELECT checkpointId
                FROM tb_checkpoint
                WHERE checkpointId = ?"
            );
            $sql->bind_param('s', $checkpointId);
            $sql->execute();
            $result = $sql->get_result();
            if ($result->num_rows > 0) {
                try {
                    $conn->begin_transaction();

                    $sql = $conn->prepare(
                        "UPDATE tb_checkpoint
                        SET checkpointName = ?, userName = ?, checkStatus = '0', isDeleted = '0'
                        WHERE checkpointId = ?"
                    );
                    $sql->bind_param('sss', $checkpointName, $userName, $checkpointId);
                    if ($sql->execute() === FALSE) throw new Exception('Statement UPDATE Failed');

                } catch (Exception $e) {
                    $output->status = 'failed';
                    echo (json_encode($output));
                    $conn->rollback();
                    exit();
                } finally {
                    $output->status = 'success';
                    echo (json_encode($output));
                    $conn->commit();
                }
            } else {
                try {
                    $conn->begin_transaction();

                    $sql = $conn->prepare(
                        "INSERT INTO tb_checkpoint (checkpointId, checkpointName, checkStatus, isDeleted, userName)
                        VALUES (?, ?, '0', '0', ?)"
                    );
                    $sql->bind_param('sss', $checkpointId, $checkpointName, $userName);
                    if ($sql->execute() === FALSE) throw new Exception('Statement INSERT Failed');
                    
                } catch (Exception $e) {
                    $output->status = 'failed';
                    echo (json_encode($output));
                    $conn->rollback();
                    exit();
                } finally {
                    $output->status = 'success';
                    echo (json_encode($output));
                    $conn->commit();
                }
            }
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $postHash = $_GET['hash'];
    $postDevice = $_GET['device'];

    if (isset($postHash) && !empty($postHash) && $postHash != 'undefined') {
        switch ($postDevice) {
            //GET CHECKPOINT LIST
            case 'web':
                $sql = $conn->prepare(
                    "SELECT userId 
                    FROM tb_users 
                    WHERE hashWeb = ?"
                );
                $sql->bind_param('s', $postHash);
                $sql->execute();
                $result = $sql->get_result();
                if ($result->num_rows > 0) {
                    $sql = $conn->prepare(
                        "SELECT checkpointName, checkpointId, checkLatitude, checkLongitude, checkStatus, lastUpdated 
                        FROM tb_checkpoint 
                        WHERE isDeleted = '0' 
                        ORDER BY uid ASC"
                    );
                    $sql->execute();
                    $result = $sql->get_result();
                    $checkpointArray = [];
                    while ($row = $result->fetch_assoc()) {
                        switch ($row['checkStatus']) {
                            case '0':
                                $checkpointArray[] = (object) [
                                    'ref' => $row['checkpointId'],
                                    'name' => $row['checkpointName'],
                                    'location' => $row['checkLongitude'] . ',' . $row['checkLatitude'],
                                    'update' => date('d/m/Y (H:i)', strtotime($row['lastUpdated'])),
                                    'color' => 'red',
                                    'status' => false
                                ];
                                break;
                            case '1':
                                $checkpointArray[] = (object) [
                                    'ref' => $row['checkpointId'],
                                    'name' => $row['checkpointName'],
                                    'location' => $row['checkLongitude'] . ',' . $row['checkLatitude'],
                                    'update' => date('d/m/Y (H:i)', strtotime($row['lastUpdated'])),
                                    'color' => 'black',
                                    'status' => true
                                ];
                                break;
                        }
                    }
                    $output->status = 'success';
                    $output->checkpoint = $checkpointArray;
                    echo (json_encode($output));
                } else {
                    $output->status = 'error';
                    echo (json_encode($output));
                }
                break;
            //GET CHECKPOINT NAME
            case 'mobile':
                $postId = $_GET['id'];

                if (isset($postId) && !empty($postId) && $postId != 'undefined') {
                    $sql = $conn->prepare(
                        "SELECT userId 
                        FROM tb_users 
                        WHERE hashMobile = ?"
                    );
                    $sql->bind_param('s', $postHash);
                    $sql->execute();
                    $result = $sql->get_result();
                    if ($result->num_rows > 0) {
                        $sql = $conn->prepare(
                            "SELECT checkpointName 
                            FROM tb_checkpoint 
                            WHERE checkpointId = ?"
                        );
                        $sql->bind_param('s', $postId);
                        $sql->execute();
                        $result = $sql->get_result();
                        $checkpointName;
                        while ($row = $result->fetch_assoc()) {
                            $checkpointName = $row['checkpointName'];
                        }
    
                        $output->status = 'success';
                        $output->checkpoint = $checkpointName;
                        echo (json_encode($output));
                    } else {
                        $output->status = 'error';
                        echo (json_encode($output));
                    }
                } else {
                    $output->status = 'error';
                    echo (json_encode($output));
                }
                break;
            default:
                $output->status = 'error';
                echo (json_encode($output));
                break;
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

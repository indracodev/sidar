<?php
include '../../config.php';
include '../../hash.php';
$output;

// $authorization = explode(" ", getallheaders()['Authorization']);
// $hash = $authorization[1];
// $sql = $conn->prepare("SELECT uid FROM tb_users WHERE hashWeb = ?");
// $sql->bind_param('s', $hash);
// $sql->execute();
// $result = $sql->get_result();
// if ($result->num_rows > 0) {
    
// } else {
//     header('HTTP/1.1 401 Unauthorized');
//     exit;
// }

//MANUAL AUTHENTICATION
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postName = $_POST['username'];
    $postPassword = $_POST['password'];
    $device = $_POST['device'];
    $action = $_GET['action'];

    if (
        isset($postName) && !empty($postName) && $postName != 'undefined' &&
        isset($postPassword) && !empty($postPassword) && $postPassword != 'undefined' &&
        isset($device) && !empty($device) && $device != 'undefined'
    ) {
        $username = strtolower($postName) ?? '';
        $password = hash('sha256', $postPassword);
        $sql = $conn->prepare(
            "SELECT userName, userPassword, userLevel
            FROM tb_users
            WHERE userName = ?
            AND userPassword = ?"
        );
        $sql->bind_param("ss", $postName, $password);
        $sql->execute();
        $result = $sql->get_result();
        $userLevel; $usernameDB; $passwordDB;
        while ($row = $result->fetch_assoc()) {
            $userLevel = $row["userLevel"];
            $usernameDB = $row["userName"];
            $passwordDB = $row["userPassword"];
        }

        if ($userLevel > 0) {
            if ($password == $passwordDB && $username == $usernameDB) {
                $hash = generateHash();
                $sql;
                switch ($device) {
                    case 'web':
                        $sql = $conn->prepare(
                            "UPDATE tb_users
                            SET hashWeb = ?
                            WHERE userName = ?"
                        );
                        break;
                    case 'mobile':
                        $sql = $conn->prepare(
                            "UPDATE tb_users
                            SET hashMobile = ?
                            WHERE userName = ?"
                        );
                        break;
                }
                $sql->bind_param("ss", $hash, $username);

                try {
                    $conn->begin_transaction();

                    if ($sql->execute() === FALSE) throw new Exception('Statement UPDATE Failed');
                    
                } catch (Exception $e) {
                    $output->status = 'failed';
                    echo (json_encode($output));
                    $conn->rollback();
                    exit();
                } finally {
                    if (!empty($action)) {
                        switch ($device) {
                            case 'web':
                                $output->status = 'success';
                                $output->level = $row['userLevel'];
                                $output->hash = $hash;
                                break;
                            case 'mobile':
                                $output->status = 'success';
                                $output->hash = $hash;
                                break;
                        }
                        echo (json_encode($output));
                    } else {
                        $output->status = 'error';
                        $output->message = 'No action';
                        echo (json_encode($output));
                    }
                    $conn->commit();
                }
            } else {
                $output->status = 'error';
                $output->message = 'Wrong combination';
                echo (json_encode($output));
            }
        } else {
            $output->status = 'error';
            $output->message = 'Wrong combination';
            echo (json_encode($output));
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
    
}

//AUTO AUTHENTICATION
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $hash = $_GET['hash'];
    $device = $_GET['device'];

    if (
        isset($hash) && !empty($hash) && $hash != 'undefined' &&
        isset($device) && !empty($device) && $device != 'undefined'
    ) {
        $sql;
        switch ($device) {
            case 'web':
                $sql = $conn->prepare(
                    "SELECT username, userLevel
                    FROM tb_users
                    WHERE hashWeb = ?"
                );
                break;
            case 'mobile':
                $sql = $conn->prepare(
                    "SELECT username
                    FROM tb_users
                    WHERE hashMobile = ?"
                );
                break;
            default: break;
        }
        
        $sql->bind_param("s", $hash);
        $sql->execute();
        $result = $sql->get_result();
        if ($result->num_rows > 0) {
            $userLevel;
            while ($row = $result->fetch_assoc()) {
                $userLevel = $row['userLevel'];
            }

            switch ($device) {
                case 'web':
                    $output->status = 'success';
                    $output->level = $userLevel;
                    break;
                case 'mobile':
                    $output->status = 'success';
                    break;
            }
            echo (json_encode($output));
        } else {
            $output->status = 'error';
            $output->message = 'No authentication';
            echo (json_encode($output));
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}
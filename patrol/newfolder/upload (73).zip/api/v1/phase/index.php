<?php
include '../../config.php';
$output;

//REMOVE PHASE
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    parse_str(file_get_contents("php://input"), $_DELETE);
    $phaseId = $_DELETE['phase'];
    $userHash = $_DELETE['hash'];

    if (
        isset($phaseId) && !empty($phaseId) && $phaseId != 'undefined' &&
        isset($userHash) && !empty($userHash) && $userHash != 'undefined'
    ) {
        $sql = $conn->prepare(
            "SELECT userName 
            FROM tb_users 
            WHERE hashWeb = ?"
        );
        $sql->bind_param('s', $userHash);
        $sql->execute();
        $result = $sql->get_result();
        if ($result->num_rows > 0) {
            try {
                $conn->begin_transaction();

                $sql = $conn->prepare(
                    "DELETE FROM tb_phase 
                    WHERE phaseId = ?"
                );
                $sql->bind_param('s', $phaseId);
                if ($sql->execute() === FALSE) throw new Exception('Statement DELETE Failed');
                
            } catch (Exception $e) {
                $output->status = 'failed';
                echo (json_encode($output));
                $conn->rollback();
                exit();
            } finally {
                $output->status = 'success';
                echo (json_encode($output));
                $conn->commit();
            }
        } else {
            $output->status = 'error';
            $output->message = 'No authentication';
            echo (json_encode($output));
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $phaseDate = $_GET['date'];
    $action = $_GET['action'];

    if (
        isset($phaseDate) && !empty($phaseDate) && $phaseDate != 'undefined' &&
        isset($action) && !empty($action) && $action != 'undefined'
    ) {
        switch ($action) {
            //GET PHASE DASHBOARD
            case 'dashboard':
                $sql = $conn->prepare(
                    "SELECT DISTINCT tb_phase.phaseId 
                    FROM tb_phase, tb_schedule 
                    WHERE tb_phase.phaseId = tb_schedule.phaseId 
                    AND tb_phase.phaseDate = ?"
                );
                $sql->bind_param("s", $phaseDate);
                $sql->execute();
                $result = $sql->get_result();
                if ($result->num_rows > 0) {
                    $phase = [];
                    while ($row = $result->fetch_assoc()) {
                        array_push($phase, $row['phaseId']);
                    }
                    $output->status = 'success';
                    $output->phaseId = $phase;
                    echo (json_encode($output));
                } else {
                    $output->status = 'false';
                    echo (json_encode($output));
                }
                break;
            //GET PHASE SCHEDULE
            case 'schedule':
                $sql = $conn->prepare(
                    "SELECT phaseId 
                    FROM tb_phase 
                    WHERE phaseDate = ?"
                );
                $sql->bind_param("s", $phaseDate);
                $sql->execute();
                $result = $sql->get_result();
                $phase = [];
                while ($row = $result->fetch_assoc()) {
                    array_push($phase, $row['phaseId']);
                }
                $output->status = 'success';
                $output->phaseId = $phase;
                echo (json_encode($output));
                break;
            default:
                $output->status = 'error';
                echo (json_encode($output));
                break;
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phaseDate = $_POST['date'];
    $action = $_GET['action'];

    if (isset($phaseDate) && !empty($phaseDate) && $phaseDate != 'undefined') {
        switch ($action) {
            //ADD PHASE
            case 'add':
                $sql = $conn->prepare(
                    "SELECT phaseId 
                    FROM tb_phase 
                    ORDER BY uid DESC LIMIT 1"
                );
                $sql->execute();
                $result = $sql->get_result();
                $phaseId = '1';
                while ($row = $result->fetch_assoc()) {
                    $phaseId = (int)$row['phaseId'] + 1;
                }
        
                try {
                    $conn->begin_transaction();
        
                    $sql = $conn->prepare(
                        "INSERT INTO tb_phase (phaseId, phaseDate) 
                        VALUES (?, ?)"
                    );
                    $sql->bind_param('ss', $phaseId, $phaseDate);
                    if ($sql->execute() === FALSE) throw new Exception('Statement INSERT Failed');

                } catch (Exception $e) {
                    $output->status = 'failed';
                    echo (json_encode($output));
                    $conn->rollback();
                    exit();
                } finally {
                    $output->status = 'success';
                    echo (json_encode($output));
                    $conn->commit();
                }
                break;
            //DUPLICATE PHASE
            case 'duplicate':
                $selectDate = $_POST['date-select'];
                $userHash = $_POST['hash'];

                if (
                    isset($selectDate) && !empty($selectDate) && $selectDate != 'undefined' &&
                    isset($userHash) && !empty($userHash) && $userHash != 'undefined'
                ) {
                    $sql = $conn->prepare(
                        "SELECT userName 
                        FROM tb_users 
                        WHERE hashWeb = ?"
                    );
                    $sql->bind_param('s', $userHash);
                    $sql->execute();
                    $result = $sql->get_result();
                    $userName;
                    while ($row = $result->fetch_assoc()) {
                        $userName = $row['userName'];
                    }

                    $sql = $conn->prepare(
                        "SELECT DISTINCT phaseId
                        FROM tb_schedule
                        WHERE scheduleDate = ?"
                    );
                    $sql->bind_param('s', $phaseDate);
                    $sql->execute();
                    $result = $sql->get_result();
                    $isSuccess = false;
                    while ($row = $result->fetch_assoc()) {

                        $sql = $conn->prepare(
                            "SELECT phaseId
                            FROM tb_phase
                            ORDER BY uid DESC LIMIT 1"
                        );
                        $sql->execute();
                        $subResult = $sql->get_result();
                        $phaseId;
                        while ($subrow = $subResult->fetch_assoc()) {
                            $phaseId = (int)$subrow['phaseId'] + 1;
                        }

                        try {
                            $conn->begin_transaction();

                            //INSERT PHASE
                            $sql = $conn->prepare(
                                "INSERT INTO tb_phase
                                (phaseId, phaseDate) 
                                VALUES (?, ?)"
                            );
                            $sql->bind_param('ss', $phaseId, $selectDate);
                            if ($sql->execute() === FALSE) throw new Exception('Statement INSERT Failed');
                            
                            $sql = $conn->prepare(
                                "SELECT scheduleId, mappingId, personId, activityId, checkpointName, scheduleStart, scheduleEnd
                                FROM tb_schedule
                                WHERE phaseId = ?"
                            );
                            $sql->bind_param('s', $row['phaseId']);
                            $sql->execute();
                            $subResult = $sql->get_result();
                            while ($subrow = $subResult->fetch_assoc()) {

                                $sql = $conn->prepare(
                                    "SELECT scheduleId
                                    FROM tb_schedule
                                    ORDER BY uid DESC LIMIT 1"
                                );
                                $sql->execute();
                                $nestedResult = $sql->get_result();
                                $scheduleId;
                                while ($nestedrow = $nestedResult->fetch_assoc()) {
                                    $scheduleId = (int)$nestedrow['scheduleId'] + 1;
                                }

                                $sql = $conn->prepare(
                                    "SELECT activityId
                                    FROM tb_activity
                                    ORDER BY uid DESC LIMIT 1"
                                );
                                $sql->execute();
                                $nestedResult = $sql->get_result();
                                $activityId;
                                while ($nestedrow = $nestedResult->fetch_assoc()) {
                                    $activityId = (int)$nestedrow['activityId'] + 1;
                                }

                                //INSERT SCHEDULE
                                $sql = $conn->prepare(
                                    "INSERT INTO tb_schedule
                                    (scheduleId, mappingId, personId, activityId, checkpointName, phaseId, scheduleStart, scheduleEnd, scheduleDate, userName)
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
                                );
                                $sql->bind_param('ssssssssss', $scheduleId, $subrow['mappingId'], $subrow['personId'], $subrow['activityId'], $subrow['checkpointName'], $phaseId, $subrow['scheduleStart'], $subrow['scheduleEnd'], $selectDate, $userName);
                                if ($sql->execute() === FALSE) throw new Exception('Statement INSERT Failed');

                                //INSERT ACTIVITY
                                $sql = $conn->prepare(
                                    "INSERT INTO tb_activity
                                    (activityId, personId, scheduleId, activityStatus)
                                    VALUES (?, ?, ?, '0')"
                                );
                                $sql->bind_param('sss', $activityId, $subrow['personId'], $scheduleId);
                                if ($sql->execute() === FALSE) throw new Exception('Statement INSERT Failed');

                                $sql = $conn->prepare(
                                    "SELECT taskId
                                    FROM tb_task_list
                                    WHERE scheduleId = ?"
                                );
                                $sql->bind_param('s', $subrow['scheduleId']);
                                $sql->execute();
                                $nestedResult = $sql->get_result();
                                while ($nestedrow = $nestedResult->fetch_assoc()) {

                                    //INSERT TASK LIST
                                    $sql = $conn->prepare(
                                        "INSERT INTO tb_task_list
                                        (taskId, scheduleId, taskStatus, userName)
                                        VALUES (?, ?, '0', ?)"
                                    );
                                    $sql->bind_param('sss', $nestedrow['taskId'], $scheduleId, $userName);
                                    if ($sql->execute() === FALSE) throw new Exception('Statement INSERT Failed');

                                }

                            }

                        } catch (Exception $e) {
                            $output->status = 'failed';
                            echo (json_encode($output));
                            $conn->rollback();
                            exit();
                        } finally {
                            $isSuccess = true;
                            $conn->commit();
                        }
                    }

                    if ($isSuccess) {
                        $output->status = 'success';
                        echo (json_encode($output));
                    }
                } else {
                    $output->status = 'error';
                    echo (json_encode($output));
                }
                break;
            default:
                $output->status = 'error';
                echo (json_encode($output));
                break;
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

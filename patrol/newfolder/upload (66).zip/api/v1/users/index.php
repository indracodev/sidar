<?php
include '../../config.php';
include '../../hash.php';
$output;

//Checked
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $userHash = $_GET['hash'];

    if (isset($userHash) && !empty($userHash) && $userHash != 'undefined') {
        $sql = $conn->prepare(
            "SELECT userLevel 
            FROM tb_users 
            WHERE hashWeb = ?"
        );
        $sql->bind_param('s', $userHash);
        $sql->execute();
        $resultCheck = $sql->get_result();
        if ($resultCheck->num_rows > 0) {
            $userLevel;
            while ($rowCheck = $resultCheck->fetch_assoc()) {
                $userLevel = $rowCheck['userLevel'];
            }

            switch ($userLevel) {
                case '10':
                    $sql = $conn->prepare(
                        "SELECT userName, userId, userLevel, lastUpdated 
                        FROM tb_users"
                    );
                    $sql->execute();
                    $result = $sql->get_result();
                    if ($result->num_rows > 0) {
                        $userArray = [];
                        $i = 1;
                        while ($row = $result->fetch_assoc()) {

                            if ($row['userLevel'] > 0) {
                                $userArray[] = (object) [
                                    'no' => $i,
                                    'id' => $row['userId'],
                                    'name' => $row['userName'],
                                    'status' => 'black',
                                    'level' => $row['userLevel'],
                                    'update' => date('d/m/Y (H:i)', strtotime($row['lastUpdated'])),
                                ];
                            } else {
                                $userArray[] = (object) [
                                    'no' => $i,
                                    'id' => $row['userId'],
                                    'name' => $row['userName'],
                                    'status' => 'red',
                                    'level' => $row['userLevel'],
                                    'update' => date('d/m/Y (H:i)', strtotime($row['lastUpdated'])),
                                ];
                            }
                            $i++;
                        }
                        $output->status = 'success';
                        $output->users = $userArray;
                        echo (json_encode($output));
                    } else {
                        $output->status = 'false';
                        echo (json_encode($output));
                    }
                    break;
                default:
                    $output->status = 'unauth';
                    echo (json_encode($output));
                    break;
            }
        } else {
            $output->status = 'error';
            $output->message = 'No authentication';
            echo (json_encode($output));
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

//Checked
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    parse_str(file_get_contents("php://input"), $_PUT);
    $userId = $_PUT['id'];
    $userHash = $_PUT['hash'];
    $action = $_GET['action'];

    if (
        isset($userId) && !empty($userId) && $userId != 'undefined' &&
        isset($userHash) && !empty($userHash) && $userHash != 'undefined'
    ) {
        switch ($action) {
            case 'update':
                $userName = $_PUT['user'];

                if (isset($userName) && !empty($userName) && $userName != 'undefined') {
                    $sql = $conn->prepare(
                        "SELECT userLevel 
                        FROM tb_users 
                        WHERE hashWeb = ?"
                    );
                    $sql->bind_param('s', $userHash);
                    $sql->execute();
                    $resultCheck = $sql->get_result();
                    if ($resultCheck->num_rows > 0) {
                        $userLevel;
                        while ($rowCheck = $resultCheck->fetch_assoc()) {
                            $userLevel = $rowCheck['userLevel'];
                        }
            
                        switch ($userLevel) {
                            case '10':
                                try {
                                    $conn->begin_transaction();
            
                                    $sql = $conn->prepare(
                                        "UPDATE tb_users 
                                        SET userName = ? 
                                        WHERE userId = ?"
                                    );
                                    $sql->bind_param('ss', $userName, $userId);
                                    if ($sql->execute() === FALSE) {
                                        $output->status = 'failed';
                                        $output->action = 'update';
                                        echo (json_encode($output));
                                        throw new Exception('Statement UPDATE Failed');
                                    }
                                } catch (Exception $e) {
                                    $conn->rollback();
                                } finally {
                                    $output->status = 'success';
                                    echo (json_encode($output));
                                    $conn->commit();
                                }
                                break;
                            default:
                                $output->status = 'unauth';
                                echo (json_encode($output));
                                break;
                        }
                    } else {
                        $output->status = 'error';
                        $output->message = 'No authentication';
                        echo (json_encode($output));
                    }
                } else {
                    $output->status = 'error';
                    echo (json_encode($output));
                }
                break;
            case 'disable':
                $sql = $conn->prepare(
                    "SELECT userLevel 
                    FROM tb_users 
                    WHERE hashWeb = ?"
                );
                $sql->bind_param('s', $userHash);
                $sql->execute();
                $resultCheck = $sql->get_result();
                if ($resultCheck->num_rows > 0) {
                    $userLevel;
                    while ($rowCheck = $resultCheck->fetch_assoc()) {
                        $userLevel = $rowCheck['userLevel'];
                    }
        
                    switch ($userLevel) {
                        case '10':
                            try {
                                $conn->begin_transaction();
        
                                $sql = $conn->prepare(
                                    "UPDATE tb_users 
                                    SET userLevel = '0' 
                                    WHERE userId = ?"
                                );
                                $sql->bind_param('s', $userId);
                                if ($sql->execute() === FALSE) {
                                    $output->status = 'failed';
                                    $output->action = 'update';
                                    echo (json_encode($output));
                                    throw new Exception('Statement UPDATE Failed');
                                }
                            } catch (Exception $e) {
                                $conn->rollback();
                            } finally {
                                $output->status = 'success';
                                echo (json_encode($output));
                                $conn->commit();
                            }
                            break;
                        default:
                            $output->status = 'unauth';
                            echo (json_encode($output));
                            break;
                    }
                } else {
                    $output->status = 'error';
                    $output->message = 'No authentication';
                    echo (json_encode($output));
                }
                break;
            case 'disable':
                $sql = $conn->prepare(
                    "SELECT userLevel 
                    FROM tb_users 
                    WHERE hashWeb = ?"
                );
                $sql->bind_param('s', $userHash);
                $sql->execute();
                $resultCheck = $sql->get_result();
                if ($resultCheck->num_rows > 0) {
                    $userLevel;
                    while ($rowCheck = $resultCheck->fetch_assoc()) {
                        $userLevel = $rowCheck['userLevel'];
                    }
        
                    switch ($userLevel) {
                        case '10':
                            try {
                                $conn->begin_transaction();
        
                                $sql = $conn->prepare(
                                    "UPDATE tb_users 
                                    SET userLevel = '0' 
                                    WHERE userId = ?"
                                );
                                $sql->bind_param('s', $userId);
                                if ($sql->execute() === FALSE) {
                                    $output->status = 'failed';
                                    $output->action = 'update';
                                    echo (json_encode($output));
                                    throw new Exception('Statement UPDATE Failed');
                                }
                            } catch (Exception $e) {
                                $conn->rollback();
                            } finally {
                                $output->status = 'success';
                                echo (json_encode($output));
                                $conn->commit();
                            }
                            break;
                        default:
                            $output->status = 'unauth';
                            echo (json_encode($output));
                            break;
                    }
                } else {
                    $output->status = 'error';
                    $output->message = 'No authentication';
                    echo (json_encode($output));
                }
                break;
            case 'enable':
                $sql = $conn->prepare(
                    "SELECT userLevel 
                    FROM tb_users 
                    WHERE hashWeb = ?"
                );
                $sql->bind_param('s', $userHash);
                $sql->execute();
                $resultCheck = $sql->get_result();
                if ($resultCheck->num_rows > 0) {
                    $userLevel;
                    while ($rowCheck = $resultCheck->fetch_assoc()) {
                        $userLevel = $rowCheck['userLevel'];
                    }
        
                    switch ($userLevel) {
                        case '10':
                            try {
                                $conn->begin_transaction();
        
                                $sql = $conn->prepare(
                                    "UPDATE tb_users 
                                    SET userLevel = '1' 
                                    WHERE userId = ?"
                                );
                                $sql->bind_param('s', $userId);
                                if ($sql->execute() === FALSE) {
                                    $output->status = 'failed';
                                    $output->action = 'update';
                                    echo (json_encode($output));
                                    throw new Exception('Statement UPDATE Failed');
                                }
                            } catch (Exception $e) {
                                $conn->rollback();
                            } finally {
                                $output->status = 'success';
                                echo (json_encode($output));
                                $conn->commit();
                            }
                            break;
                        default:
                            $output->status = 'unauth';
                            echo (json_encode($output));
                            break;
                    }
                } else {
                    $output->status = 'error';
                    $output->message = 'No authentication';
                    echo (json_encode($output));
                }
                break;
            case 'logout':
                $sql = $conn->prepare(
                    "SELECT userLevel 
                    FROM tb_users 
                    WHERE hashWeb = ?"
                );
                $sql->bind_param('s', $userHash);
                $sql->execute();
                $resultCheck = $sql->get_result();
                if ($resultCheck->num_rows > 0) {
                    $userLevel;
                    while ($rowCheck = $resultCheck->fetch_assoc()) {
                        $userLevel = $rowCheck['userLevel'];
                    }
        
                    switch ($userLevel) {
                        case '10':
                            try {
                                $conn->begin_transaction();

                                $hashWeb = generateHash();
                                $hashMobile = generateHash();
        
                                $sql = $conn->prepare(
                                    "UPDATE tb_users 
                                    SET hashWeb = ?, hashMobile = ? 
                                    WHERE userId = ?"
                                );
                                $sql->bind_param('sss', $hashWeb, $hashMobile, $userId);
                                if ($sql->execute() === FALSE) {
                                    $output->status = 'failed';
                                    $output->action = 'update';
                                    echo (json_encode($output));
                                    throw new Exception('Statement UPDATE Failed');
                                }
                            } catch (Exception $e) {
                                $conn->rollback();
                            } finally {
                                $output->status = 'success';
                                echo (json_encode($output));
                                $conn->commit();
                            }
                            break;
                        default:
                            $output->status = 'unauth';
                            echo (json_encode($output));
                            break;
                    }
                } else {
                    $output->status = 'error';
                    $output->message = 'No authentication';
                    echo (json_encode($output));
                }
                break;
            default: break;
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

//Checked
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userName = strtolower($_POST['user']);
    $userPassword = hash('sha256', $_POST['password']);
    $userHash = $_POST['hash'];

    if (
        isset($userName) && !empty($userName) && $userName != 'undefined' &&
        isset($userPassword) && $userPassword != '' && $userPassword != 'undefined' &&
        isset($userHash) && !empty($userHash) && $userHash != 'undefined'
    ) {
        $sql = $conn->prepare(
            "SELECT userLevel 
            FROM tb_users 
            WHERE hashWeb = ?"
        );
        $sql->bind_param('s', $userHash);
        $sql->execute();
        $result = $sql->get_result();
        if ($result->num_rows > 0) {
            $userLevel;
            while ($row = $result->fetch_assoc()) {
                $userLevel = $row['userLevel'];
            }

            switch ($userLevel) {
                case '10':
                    try {
                        $conn->begin_transaction();

                        $userId = 0;
                        $sql = $conn->prepare(
                            "SELECT userId
                            FROM tb_users
                            ORDER BY userId DESC LIMIT 1"
                        );
                        $sql->execute();
                        $result = $sql->get_result();
                        while ($row = $result->fetch_assoc()) {
                            $userId = $row['userId'] + 1;
                        }

                        $sql = $conn->prepare(
                            "INSERT INTO tb_users 
                            (userId, userName, userPassword, userLevel)
                            VALUES (?, ?, ?, '0')"
                        );
                        $sql->bind_param('sss', $userId, $userName, $userPassword);
                        if ($sql->execute() === FALSE) {
                            $output->status = 'failed';
                            $output->action = 'insert';
                            echo (json_encode($output));
                            throw new Exception('Statement INSERT Failed');
                        }
                    } catch (Exception $e) {
                        $conn->rollback();
                    } finally {
                        $output->status = 'success';
                        echo (json_encode($output));
                        $conn->commit();
                    }
                    break;
                default:
                    $output->status = 'unauth';
                    echo (json_encode($output));
                    break;
            }
        } else {
            $output->status = 'error';
            $output->message = 'No authentication';
            echo (json_encode($output));
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}
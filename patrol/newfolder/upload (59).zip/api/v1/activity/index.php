<?php
include '../../config.php';
$output;

//Checked
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_GET['action'];

    switch ($action) {
        case 'prepare':
            $sql = $conn->prepare(
                "SELECT tb_activity.activityId, activityStatus
                FROM tb_activity, tb_schedule
                WHERE tb_activity.activityId = tb_schedule.activityId
                AND CONCAT(scheduleDate, ' ', scheduleStart) < DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 30 MINUTE)
                AND CONCAT(scheduleDate, ' ', scheduleEnd) < DATE_SUB(CURRENT_TIMESTAMP, INTERVAL 30 MINUTE)
                AND activityStatus = '0'"
            );
            $sql->execute();
            $skipper = $sql->get_result();
            if ($skipper->num_rows > 0) {

                $isSuccess = false;

                try {
                    $conn->begin_transaction();

                    while ($row = $skipper->fetch_assoc()) {
                        $sql = $conn->prepare(
                            "UPDATE tb_activity
                            SET activityStatus = '-'
                            WHERE activityId = ?"
                        );
                        $sql->bind_param('s', $row['activityId']);
                        if ($sql->execute() === FALSE) {
                            $isSuccess = false;
                            throw new Exception('Statement UPDATE Failed');
                        }
                    }
                } catch (Exception $e) {
                    $conn->rollback();
                } finally {
                    $isSuccess = true;
                    $conn->commit();
                }

                if ($isSuccess) {
                    $output->status = 'success';
                    echo (json_encode($output));
                } else {
                    $output->status = 'failed';
                    $output->action = 'update';
                    $output->table = 'activity';
                    echo (json_encode($output));
                }
            } else {
                $output->status = 'success';
                echo (json_encode($output));
            }
            break;
        case 'activity':
            $mappingTag = $_POST['person'];
            
            if (isset($mappingTag) && !empty($mappingTag) && $mappingTag != 'undefined') {
                //Get Mapping ID
                $sql = $conn->prepare(
                    "SELECT mappingId
                    FROM tb_person_mapping
                    WHERE mappingTag = ?"
                );
                $sql->bind_param('s', $mappingTag);
                $sql->execute();
                $getMappingId = $sql->get_result();
                $mappingId;
                while ($row = $getMappingId->fetch_assoc()) {
                    $mappingId = $row['mappingId'];
                }

                //Get Schedule by Mapping ID
                $sql = $conn->prepare(
                    "SELECT tb_schedule.scheduleId, tb_schedule.checkpointName, tb_person.personId, personName, tb_activity.activityId, scheduleStart, scheduleEnd
                    FROM tb_schedule, tb_person, tb_activity
                    WHERE mappingId = ?
                    AND tb_schedule.activityId = tb_activity.activityId
                    AND tb_schedule.personId = tb_person.personId
                    AND scheduleDate = CURRENT_DATE()
                    AND activityStatus = '0'"
                );
                $sql->bind_param('s', $mappingId);
                $sql->execute();
                $getSchedule = $sql->get_result();
                $schedule = [];
                $checkpointSchedule = [];
                while ($row = $getSchedule->fetch_assoc()) {
                    
                    //Get Task by Schedule ID
                    $sql = $conn->prepare(
                        "SELECT tb_task_list.taskId, taskName
                        FROM tb_task_list, tb_task
                        WHERE tb_task.taskId = tb_task_list.taskId
                        AND scheduleId = ?"
                    );
                    $sql->bind_param('s', $row['scheduleId']);
                    $sql->execute();
                    $getTask = $sql->get_result();
                    $task = [];
                    while ($subrow = $getTask->fetch_assoc()) {

                        $task[] = (object) [
                            'taskId' => $subrow['taskId'],
                            'taskName' => $subrow['taskName'],
                            'taskStatus' => '0'
                        ];

                    }

                    //Set Response
                    $schedule[] = (object) [
                        'activityId' => $row['activityId'],
                        'personId' => $row['personId'],
                        'personName' => $row['personName'],
                        'checkpointStart' => null,
                        'checkpointEnd' => null,
                        'scheduleId' => $row['scheduleId'],
                        'scheduleStart' => $row['scheduleStart'],
                        'scheduleEnd' => $row['scheduleEnd'],
                        'activityStart' => null,
                        'activityEnd' => null,
                        'latitudeStart' => null,
                        'longitudeStart' => null,
                        'latitudeEnd' => null,
                        'longitudeEnd' => null,
                        'reportNote' => null,
                        'reportDate' => null,
                        'reportTime' => null,
                        'activityStatus' => '0',
                        'isUploaded' => '0',
                        'task' => $task
                    ];

                    $checkpointSchedule[] = (object) [
                        'checkpoint' => $row['checkpointName'],
                        'status' => 'red'
                    ];
                }

                $sql = $conn->prepare(
                    "SELECT checkpointName, checkpointId
                    FROM tb_checkpoint 
                    WHERE isDeleted = '0' 
                    ORDER BY checkpointName DESC"
                );
                $sql->execute();
                $getCheckpoint = $sql->get_result();
                $checkpoint = [];
                while ($row = $getCheckpoint->fetch_assoc()) {

                    $checkpoint[] = (object) [
                        'checkpointId' => $row['checkpointId'],
                        'checkpointName' => $row['checkpointName'],
                        'status' => 'red'
                    ];

                }

                count($schedule) > 0 ? $output->status = 'success' : $output->status = 'false';
                $output->schedule = $schedule;
                $output->checkpoint = $checkpoint;
                $output->checkpointSchedule = $checkpointSchedule;
                echo (json_encode($output));
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
        case 'schedule':
            $userHash = $_GET['hash'];
            $personId = $_POST['person'];

            if (
                isset($personId) && !empty($personId) && $personId != 'undefined' &&
                isset($userHash) && !empty($userHash) && $userHash != 'undefined'
            ) {
                $sql = $conn->prepare(
                    "SELECT userName
                    FROM tb_users
                    WHERE hashWeb = ?"
                );
                $sql->bind_param('s', $userHash);
                $sql->execute();
                $userResult = $sql->get_result();
                if ($userResult->num_rows > 0) {
                    $sql = $conn->prepare(
                        "SELECT activityId
                        FROM tb_activity
                        ORDER BY uid DESC LIMIT 1"
                    );
                    $sql->execute();
                    $resultCheck = $sql->get_result();
                    $activityId = '1';
                    while ($rowCheck = $resultCheck->fetch_assoc()) {
                        $activityId = (int)$rowCheck['activityId'] + 1;
                    }

                    try {
                        $conn->begin_transaction();

                        $sql = $conn->prepare(
                            "INSERT INTO tb_activity (activityId, personId, activityStatus)
                            VALUES (?, ?, '0')"
                        );
                        $sql->bind_param("is", $activityId, $personId);
                        if ($sql->execute() === FALSE) {
                            $output->status = 'failed';
                            $output->action = 'insert';
                            $output->action = 'activity';
                            echo (json_encode($output));
                            throw new Exception('Statement INSERT Failed');
                        }
                    } catch (Exception $e) {
                        $conn->rollback();
                    } finally {
                        $output->status = 'success';
                        $output->activity = $activityId;
                        echo (json_encode($output));
                        $conn->commit();
                    }
                } else {
                    $output->status = 'false';
                    echo (json_encode($output));
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
    }
}

//Checked
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $phaseId = $_GET['phase'];
    $scheduleId = $_GET['schedule'];
    $userHash = $_GET['hash'];

    if (isset($scheduleId) && !empty($scheduleId) && $scheduleId != 'undefined') {
        $sql = $conn->prepare(
            "SELECT phaseId
            FROM tb_schedule
            WHERE scheduleId = ?"
        );
        $sql->bind_param('s', $scheduleId);
        $sql->execute();
        $phaseResult = $sql->get_result();
        if ($phaseResult->num_rows > 0) {
            $phaseId;
            while ($rowPhase = $phaseResult->fetch_assoc()) {
                $phaseId = $rowPhase['phaseId'];
            }
            $sql = $conn->prepare(
                "SELECT checkpointName
                FROM tb_schedule
                WHERE phaseId = ?"
            );
            $sql->bind_param('s', $phaseId);
            $sql->execute();
            $progress = $sql->get_result();
            if ($progress->num_rows > 0) {
                $scheduleArray = [];
                while ($rowProgress = $progress->fetch_assoc()) {

                    $sql = $conn->prepare(
                        "SELECT checkpointStart, activityStatus
                        FROM tb_schedule, tb_activity
                        WHERE tb_activity.activityId = tb_schedule.activityId
                        AND tb_activity.checkpointStart = ?
                        AND tb_schedule.phaseId = ?"
                    );
                    $sql->bind_param('ss', $rowProgress['checkpointName'], $phaseId);
                    $sql->execute();
                    $result = $sql->get_result();
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {

                            switch ($row['activityStatus']) {
                                case '0':
                                    $scheduleArray[] = (object) [
                                        'checkpoint' => $row['checkpointStart'],
                                        'status' => 'blue'
                                    ];
                                    break;
                                case '1':
                                    $scheduleArray[] = (object) [
                                        'checkpoint' => $row['checkpointStart'],
                                        'status' => 'green'
                                    ];
                                    break;
                                default:
                                    $scheduleArray[] = (object) [
                                        'checkpoint' => $rowProgress['checkpointName'],
                                        'status' => 'red'
                                    ];
                                    break;
                            }
                        }
                    } else {
                        $scheduleArray[] = (object) [
                            'checkpoint' => $rowProgress['checkpointName'],
                            'status' => 'red'
                        ];
                    }
                }
                $output->status = 'success';
                $output->schedule = $scheduleArray;
                echo (json_encode($output));
            } else {
                $output->status = 'false';
                echo (json_encode($output));
            }
        } else {
            $output->status = 'false';
            echo (json_encode($output));
        }
    } elseif (
        isset($userHash) && !empty($userHash) && $userHash != 'undefined' &&
        isset($phaseId) && !empty($phaseId) && $phaseId != 'undefined'
    ) {

        $sql = $conn->prepare(
            "SELECT checkpointName, personName
            FROM tb_schedule, tb_person
            WHERE tb_person.personId = tb_schedule.personId
            AND tb_schedule.phaseId = ?"
        );
        $sql->bind_param('s', $phaseId);
        $sql->execute();
        $progress = $sql->get_result();
        if ($progress->num_rows > 0) {
            $scheduleArray = [];
            while ($rowProgress = $progress->fetch_assoc()) {

                $sql = $conn->prepare(
                    "SELECT checkpointStart, activityStatus, activityStart, activityEnd, personName,
                    SEC_TO_TIME(TIMESTAMPDIFF(SECOND, CONCAT(scheduleDate, ' ', scheduleStart), activityStart)) as elapseStart,
                    SEC_TO_TIME(TIMESTAMPDIFF(SECOND, CONCAT(scheduleDate, ' ', scheduleEnd), activityEnd)) as elapseEnd
                    FROM tb_schedule, tb_activity, tb_person
                    WHERE tb_activity.activityId = tb_schedule.activityId
                    AND tb_person.personId = tb_activity.personId
                    AND tb_activity.checkpointStart = ?
                    AND tb_schedule.phaseId = ?"
                );
                $sql->bind_param('ss', $rowProgress['checkpointName'], $phaseId);
                $sql->execute();
                $result = $sql->get_result();
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {

                        switch ($row['activityStatus']) {
                            case '0':
                                $eStartStatus;
                                if (substr(detectTime($row['elapseStart']), 0, 1) == '+') {
                                    $eStartStatus = 'blue';
                                }

                                if (substr(detectTime($row['elapseStart']), 0, 1) == '-') {
                                    $eStartStatus = 'red';
                                }

                                $scheduleArray[] = (object)[
                                    'checkpoint' => $rowProgress['checkpointName'],
                                    'start' => date('j M H:i:s', strtotime($row['activityStart'])),
                                    'elapseStart' => detectTime($row['elapseStart']),
                                    'eStartStatus' => $eStartStatus,
                                    'end' => null,
                                    'elapseEnd' => null,
                                    'eEndStatus' => null,
                                    'person' => ucfirst($row['personName']),
                                    'status' => 'blue'
                                ];
                                break;
                            case '1':
                                $eStartStatus;
                                $eEndStatus;
                                if (substr(detectTime($row['elapseStart']), 0, 1) == '+') {
                                    $eStartStatus = 'blue';
                                }

                                if (substr(detectTime($row['elapseEnd']), 0, 1) == '+') {
                                    $eEndStatus = 'blue';
                                }

                                if (substr(detectTime($row['elapseStart']), 0, 1) == '-') {
                                    $eStartStatus = 'red';
                                }

                                if (substr(detectTime($row['elapseEnd']), 0, 1) == '-') {
                                    $eEndStatus = 'red';
                                }

                                $scheduleArray[] = (object) [
                                    'checkpoint' => $rowProgress['checkpointName'],
                                    'start' => date('j M H:i:s', strtotime($row['activityStart'])),
                                    'elapseStart' => detectTime($row['elapseStart']),
                                    'eStartStatus' => $eStartStatus,
                                    'end' => date('j M H:i:s', strtotime($row['activityEnd'])),
                                    'elapseEnd' => detectTime($row['elapseEnd']),
                                    'eEndStatus' => $eEndStatus,
                                    'person' => ucfirst($row['personName']),
                                    'status' => 'green'
                                ];
                                break;
                            default:
                                $scheduleArray[] = (object)[
                                    'checkpoint' => $rowProgress['checkpointName'],
                                    'start' => null,
                                    'elapseStart' => null,
                                    'eStartStatus' => null,
                                    'end' => null,
                                    'elapseEnd' => null,
                                    'eEndStatus' => null,
                                    'person' => ucfirst($rowProgress['personName']),
                                    'status' => 'red'
                                ];
                                break;
                        }
                    }
                } else {
                    $scheduleArray[] = (object)[
                        'checkpoint' => $rowProgress['checkpointName'],
                        'start' => null,
                        'elapseStart' => null,
                        'eStartStatus' => null,
                        'end' => null,
                        'elapseEnd' => null,
                        'eEndStatus' => null,
                        'person' => ucfirst($rowProgress['personName']),
                        'status' => 'red'
                    ];
                }
            }
            $output->status = 'success';
            $output->schedule = $scheduleArray;
            echo (json_encode($output));
        } else {
            $output->status = 'false';
            echo (json_encode($output));
        }
    } else {
        $output->status = 'error';
        echo (json_encode($output));
    }
}

function detectTime ($time) {
    if (substr($time, 0, 1) == '-') {
        return $time;
    } else {
        return '+'.$time;
    }
}
<?php
include '../../config.php';
$output;

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $postHash = $_GET['hash'];
    $filter = $_GET['filter'].'%';
    $action = $_GET['action'];

    switch ($action) {
        //GET REPORT BY DATE
        case 'date':
            if (isset($postHash) && !empty($postHash) && $postHash != 'undefined') {
                $sql = $conn->prepare(
                    "SELECT userId
                    FROM tb_users
                    WHERE hashWeb = ?"
                );
                $sql->bind_param('s', $postHash);
                $sql->execute();
                $result = $sql->get_result();
                if ($result->num_rows > 0) {
                    if ($filter == '%') {
                        $sql = $conn->prepare(
                            "SELECT DISTINCT reportDate
                            FROM tb_report
                            WHERE reportDate LIKE ?
                            AND reportDate != '0000-00-00'
                            ORDER BY reportDate DESC LIMIT 30"
                        );
                    } else {
                        $sql = $conn->prepare(
                            "SELECT DISTINCT reportDate 
                            FROM tb_report 
                            WHERE reportDate LIKE ? 
                            ORDER BY reportDate DESC"
                        );
                    }
                    $sql->bind_param('s', $filter);
                    $sql->execute();
                    $result = $sql->get_result();
                    if ($result->num_rows > 0) {
                        $reportDate = [];
                        while ($row = $result->fetch_assoc()) {
                            $sql = $conn->prepare(
                                "SELECT COUNT(DISTINCT tb_schedule.phaseId) as phase 
                                FROM tb_phase, tb_schedule, tb_activity 
                                WHERE tb_schedule.phaseId = tb_phase.phaseId 
                                AND tb_activity.activityId = tb_schedule.activityId 
                                AND phaseDate = ? 
                                AND checkpointStart != 'null'
                                AND activityStatus = '1'"
                            );
                            $sql->bind_param('s', $row['reportDate']);
                            $sql->execute();
                            $subResult = $sql->get_result();
                            $phaseCount;
                            while ($subrow = $subResult->fetch_assoc()) {
                                $phaseCount = $subrow['phase'];
                            }

                            $sql = $conn->prepare(
                                "SELECT DISTINCT tb_schedule.phaseId 
                                FROM tb_phase, tb_schedule, tb_activity 
                                WHERE tb_schedule.phaseId = tb_phase.phaseId 
                                AND tb_activity.activityId = tb_schedule.activityId 
                                AND phaseDate = ? 
                                AND checkpointStart != 'null'
                                AND activityStatus = '1'"
                            );
                            $sql->bind_param('s', $row['reportDate']);
                            $sql->execute();
                            $subResult = $sql->get_result();
                            $phase = [];
                            while ($subrow = $subResult->fetch_assoc()) {
                                $sql = $conn->prepare(
                                    "SELECT
                                    SUBSTRING_INDEX(GROUP_CONCAT(scheduleStart ORDER BY scheduleStart ASC), ',', 1) AS start,
                                    SUBSTRING_INDEX(GROUP_CONCAT(scheduleStart ORDER BY scheduleStart DESC), ',', 1) AS finish
                                    FROM tb_schedule
                                    WHERE phaseId = ?"
                                );
                                $sql->bind_param('s', $subrow['phaseId']);
                                $sql->execute();
                                $getTime = $sql->get_result();
                                $scheduleStart;
                                while ($timerow = $getTime->fetch_assoc()) {
                                    $scheduleStart = $timerow['start'];
                                }

                                $hours = substr($scheduleStart, 0, 2) . ":00";
                                $tempHours = substr($scheduleStart, 0, 2) . ":59";

                                $sql = $conn->prepare(
                                    "SELECT DISTINCT phaseId
                                    FROM tb_schedule
                                    WHERE scheduleStart BETWEEN ? AND ?
                                    AND scheduleDate = ?"
                                );
                                $sql->bind_param("sss", $hours, $tempHours, $row['reportDate']);
                                $sql->execute();
                                $nestedResult = $sql->get_result();
                                $schedule = [];
                                while ($nestedrow = $nestedResult->fetch_assoc()) {
                                    array_push($schedule, $nestedrow['phaseId']);
                                }

                                $phase[] = (object) [
                                    'id' => $schedule,
                                    'schedule' => $hours.' - '.$tempHours
                                ];
                            }

                            $date = date_create(substr($row['reportDate'], 0, 10));
                            $reportDate[] = (object) [
                                'id' => $row['reportDate'],
                                'date' => date_format($date, 'd F Y'),
                                'phase' => my_array_unique($phase),
                                'count' => $phaseCount
                            ];
                        }
                        $output->status = 'success';
                        $output->data = $reportDate;
                        echo (json_encode($output));
                    } else {
                        $output->status = 'false';
                        echo (json_encode($output));
                    }
                } else {
                    $output->status = 'error';
                    $output->message = 'No authentication';
                    echo (json_encode($output));
                }
            } else {
                $output->status = 'error';
                echo (json_encode($output));
            }
            break;
        //GET ALL REPORT
        case 'download':
            $date = $_GET['date'].'%';

            header( "Content-Type: application/vnd.ms-excel" );
            header( "Content-disposition: attachment; filename=".$_GET['date'].".xls" );

            // echo 'First Name' . "\t" . 'Last Name' . "\t" . 'Phone' . "\n";
            // echo 'John' . "\t" . 'Doe' . "\t" . '555-5555' . "\n";
            echo '
                <table border="1">
                    <tr>
                        <th>NO.</th>
                        <th>DATE</th>
                        <th>PHASE ID</th>
                    </tr>
            ';

            $sql = $conn->prepare(
                "SELECT DISTINCT reportDate 
                FROM tb_report 
                WHERE reportDate LIKE ? 
                ORDER BY reportDate ASC"
            );
            $sql->bind_param('s', $date);
            $sql->execute();
            $result = $sql->get_result();
            $no = 1;
            while ($row = $result->fetch_assoc()) {

                $sql = $conn->prepare(
                    "SELECT DISTINCT phaseDate, tb_schedule.phaseId 
                    FROM tb_phase, tb_schedule, tb_activity 
                    WHERE tb_schedule.phaseId = tb_phase.phaseId 
                    AND tb_activity.activityId = tb_schedule.activityId 
                    AND phaseDate = ? 
                    AND checkpointStart != 'null'
                    AND activityStatus = '1'"
                );
                $sql->bind_param('s', $row['reportDate']);
                $sql->execute();
                $subResult = $sql->get_result();
                while ($subrow = $subResult->fetch_assoc()) {
                    echo '
                        <tr>
                            <td>' . $no . '</td>
                            <td>' . $subrow['phaseDate'] . '</td>
                            <td>' . $subrow['phaseId'] . '</td>
                        </tr>
                    ';
                    $no++;
                }

            }

            echo '</table>';
            break;
        default:
            $output->status = 'error';
            echo (json_encode($output));
            break;
    }
}

function my_array_unique($array, $keep_key_assoc = false){
    $duplicate_keys = array();
    $tmp = array();       

    foreach ($array as $key => $val){
        // convert objects to arrays, in_array() does not support objects
        if (is_object($val))
            $val = (array)$val;

        if (!in_array($val, $tmp))
            $tmp[] = $val;
        else
            $duplicate_keys[] = $key;
    }

    foreach ($duplicate_keys as $key)
        unset($array[$key]);

    return $keep_key_assoc ? $array : array_values($array);
}
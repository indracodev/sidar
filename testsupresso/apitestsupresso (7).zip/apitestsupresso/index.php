<?php
header("location:../");
exit();
?>
